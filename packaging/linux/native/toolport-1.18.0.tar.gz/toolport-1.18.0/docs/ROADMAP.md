# Toolport roadmap

Toolport is a local MCP gateway for AI coding tools (Claude Desktop, Cursor,
VS Code, Devin Desktop, Devin CLI, Codex CLI). Every server you connect dumps
its whole tool list into the agent's context on every request; Toolport routes
them through one gateway that exposes 4 meta-tools the agent searches on demand,
so context stays flat: measured ~90% fewer tokens at the same task success. This
document is the working spec, capturing the architecture decision and the build
order.

> **Read this as history, not as current state.** The status notes below are dated
> snapshots and stop at v1.6.2 (2026-07-09), so their client counts and `CONDUIT_*`
> env names are period-accurate rather than current. For what ships today, see
> [CHANGELOG.md](../CHANGELOG.md) and the README; every `CONDUIT_*` name below is
> spelled `TOOLPORT_*` now (the old spelling still works as an alias).

**Status (2026-07-09):** v1.6.2 published (renamed Conduit -> Toolport at v1.0.0).
Signed/notarized macOS (Apple Silicon + Intel, data-protection keychain + nested
gateway, no keychain prompts on update), Windows (Azure Trusted Signing), Linux
(deb/AppImage) via a tag-triggered pipeline + in-app auto-updater. 22 clients.
Recently shipped: human-in-the-loop tool approval (with approve-for-session and
per-tool overrides), tray/menu-bar background running + launch-at-login, desktop
notifications on held calls, and severity-tiered security notices. Shipped: lazy
discovery, OAuth/key auth
with live propagation, catalog, import/migrate, per-tool + destructive-tool
governance, audit log, resources/prompts proxying, tool playground, semantic search,
rug-pull + injection + agentjacking detection, result-shaping Tier 1. **v0.7.0 made
Open WebUI first-class:** the gateway speaks HTTP/OpenAPI natively (`--http` /
`CONDUIT_HTTP`, mcpo retired), with a one-click in-app toggle, a required bearer
token (closing a browser drive-by CSRF), and self-resolving multi-step tool calls
(an invented-ID guard that points the model at the right list/get tool). Live
priorities are below.

## Near-term priorities (2026-07-01)

A competitive review reset the near-term order toward widening the two structural
moats (zero-infra local-first + tool-supply-chain security) and reaching parity on
a few governance/observability items other gateways have. (Detailed competitive
notes live in the internal `docs/COMPETITIVE.md`.)

**Shipped since (2026-07-03 update)** — several items below have landed and should be
read as done: the **human-in-the-loop approval queue** (+ tray/menu-bar background
run, OS notification, exact fail-closed countdown, and an org-mandated
`forceHumanApproval` policy), the **multithreaded HTTP loop + released router lock**
(supersedes "single-threaded accept loop" and "router lock held across the downstream
call" below), **tool overrides** (rename / re-describe), the **DNS-rebind TOCTOU** and
**IPv6 cloud-metadata** SSRF guards, and **audit-line client attribution** (the stamp;
a per-caller Activity filter is still open). A 2026-07-03 code audit (Teams server +
desktop app) also drove a **security hardening pass**: HTTP clients are now scoped on
`resources`/`prompts` too, three tool-poisoning detection gaps closed (outputSchema
scan, structuredContent co-occurrence, quarantine fail-closed), and gateway
durability/auth hardening (fsync, empty-bearer, constant-time token). Follow-ups since
then also landed: the **content-defense DoS byte-cap** (512KB scan bound, #110), the
**HITL/confirm fail-closed** resolution on a cache miss (#109), a **canonical
`fmtTokens`** (#111), and, on the Teams server, the full robustness batch — logout
session revoke, CSV-injection guard, secret-strip precision, Google/GitHub email
verification, `billing_success` owner-gate + webhook refetch, magic-link rate limit,
and hourly auth-row reaping (Teams #15-21, all deployed). Still open: the **seat-count
race** (atomic fix in Teams PR #22, awaiting review) and one deferred desktop item —
the **registry cross-process cache-coherence** problem (the app persists its in-memory
`Mutex<Registry>` while the gateway does its own disk load→mutate→save on agent-control
toggles, so the two can clobber each other; a file lock alone won't fix it, the correct
fix is reload-under-lock at every app mutation or a gateway→app cache-refresh signal;
low real exposure since the gateway only writes when `allow_agent_control` is on).

**Shipped since the 07-03 update (as of 2026-07-09).** The **headless gateway**
(v1.6.0: Docker image + streamable-HTTP/OpenAPI serving, env-var secrets), so the
gateway runs server-side, not only as a desktop sidecar. **Teams launched**
(2026-07-08) with a hosted control plane at teams.toolport.app, join-code onboarding,
long-poll config + policy sync, and the org approval/defense policy above. **Grouped
discovery mode** (`CONDUIT_DISCOVERY=grouped`). **AnythingLLM + Antigravity** client
support (22 clients). A Windows reliability batch: versioned gateway path, NSIS
gateway-kill on install, dev data dir, registry-recovery notice, gateway secret reload,
and serialized OAuth callback across clients. With the core feature-complete and Teams
shipped, near-term focus is distribution and growth over new engineering.

**In flight**

- ~~Teams **org screening policy** (Phase 1): tighten-only `forceContentDefense` /
  `forceQuarantineOnDrift`.~~ **Shipped**, and extended with `forceHumanApproval`
  (org-mandated HITL). Plan in `docs/drafts/parry-teams-plan.md`.

**Tier 1 - security + cheap parity (do first)**

- [x] **Stdio spawn hardening.** Refuse code-smuggling / container-escape args
      (interpreter inline-eval + module-preload, docker `--privileged` / host-mount /
      `--cap-add` / host-namespace) before spawning a stdio server, so a
      booby-trapped (team- or registry-sourced) config can't turn a benign-looking
      launcher into arbitrary code execution. `screen_spawn_command` in
      `downstream.rs`, on every spawn path. (S)
- [~] **Identity attribution in the audit line.** The client label is now threaded
  through dispatch and stamped into `audit.rs`/`inspect.rs` records (#95). Remaining:
  a per-caller filter in the Activity view. (S)
- [x] **Tool overrides (rename / re-describe) SHIPPED (#88, #89):** a user can rename or
      replace a tool's description as clients see it (neutralizing a poisoned description
      in place). Param-pin/override defaults is the remaining piece.

**Tier 2 - parity on real gaps**

- [ ] Tool Groups (cross-server reusable collections) + allow/block ACL with an
      explicit `default-allow`/`default-block` posture per client, generalizing
      profiles. (M)
- [ ] **Opt-in** OTel/Prometheus exporter (`/metrics` or OTLP push), OFF by default
      so zero-infra stays the default experience; keep the in-app dashboard primary. (M)
- [~] **Streamable-HTTP upstream transport** — `POST /mcp` and `GET /mcp` listen stream ship
  (session ids, JSON-RPC, selective SSE responses; see `docs/headless.md` +
  `docker-compose.example.yml`). OpenAPI HTTP mode already shipped for Open WebUI.
  **GHCR:** `ghcr.io/tsouth89/toolport-gateway` published from `main` (host-built
  binary + slim runtime image; see `Dockerfile` + `docker-publish.yml`). Optional
  follow-up: long-lived `GET /mcp` listen on HTTP downstream for servers that push
  RPC outside SSE POST responses. (S)

**Strategic**

- [x] **Human-in-the-loop approval queue. SHIPPED** (v1.1.0 + follow-ups): the gateway
      holds a gated call and the app prompts to approve/deny, fail-closed on timeout;
      plus tray/menu-bar run, OS notification, approve-for-session/always-allow, exact
      countdown, and an org-mandated `forceHumanApproval` Teams policy.
- [ ] **Named retention / data-handling statement** (docs + in-app one-liner):
      payloads never leave the machine; we log metadata, not bodies. Structurally
      true today, just never stated. (S)
- Teams enterprise (SSO/IdP, central catalog, approval workflows) stays
  **Teams-only** and selective; not in the local app.

## What's next (backlog, from the 2026-06-28 audit)

Prioritized after v0.7.0 and a fresh-eyes audit (code/tech-debt, first-run UX,
HTTP/security surface). Ordered by impact within each track. (S/M/L = effort.)
The 2026-07-01 block above supersedes the ordering; these remain the detailed backlog.

### Security (most shipped in v0.7.0; residuals)

- [x] HTTP bridge **bearer token** (required, OPTIONS preflight exempt), fail-closed
      on non-loopback bind, 4 MB body cap, sanitized reflected headers, `catch_unwind`
      per request. Closed the credential-CSRF (a browser tab can reach `localhost`).
- [x] IPv6 cloud-metadata is covered by the resolver-level `ip_is_private` screen.
- [x] **DNS-rebind TOCTOU SHIPPED (#81):** SSRF screening moved into the resolver so the
      validated address set is enforced at connect time (whole-set refusal), closing the
      resolve-once/connect-later window.
- [x] Worker-per-request HTTP loop **SHIPPED (#99)** — a slow downstream / held call no
      longer blocks other callers. The public HTTP ingress now also enforces absolute
      10-second header and 30-second body read deadlines before routing.

### New-user UX (first 10 minutes; scaffolding is strong, these are the sharp edges)

- [x] **Backend failures render as innocent empty states.** Gateway down ->
      Activity shows "No tool calls yet", not "can't reach backend, retry".
      Distinguish error from empty (CatalogView already does). Top UX fix. (M)
- [x] **Add-server form saves broken servers silently** (empty command/URL);
      require + inline-validate before enabling Add. (S)
- [x] ClientDetail throws Connect / Import / Move at a first-timer before teaching
      that Toolport is the gateway; lead with the mental model. (M)
- [ ] Jargon + dead ends: rename "Move config in", tooltip "Add to catalog", helper
      text on transports, make the Settings "See docs/openwebui.md" a real link,
      default Activity "Recent calls" filter off, Playground "0 tools" state,
      `vendorFromKey` fallback for unknown keys. (S each)
      **Partial:** Playground "0 tools" copy, `vendorFromKey` fallback, the Activity
      default filter, and inline OpenWebUI setup shipped; still open: rename "Move
      config in", the "Add to catalog" tooltip, and transports helper text.

### Robustness / tech debt

- [x] **Tool-cache versioning SHIPPED (2026-07-04 robustness sprint):** the cache is
      wrapped as `{version, tools}` (`TOOL_CACHE_VERSION`) and discarded on mismatch, so
      a stale cache from an older build is rebuilt rather than served verbatim.
- [x] **Router lock held across the downstream call SHIPPED (#95, #99):** the live
      router is a `Mutex<Arc<Router>>`; dispatch clones the Arc and releases the lock
      before the (possibly 120s-held) downstream call, and the HTTP loop is multithreaded.
- [x] Tests for the new HTTP transport (status mapping, error paths) and
      `semantic.rs` (blend math, embed cache). (M) HTTP round-trip/SSE/scope/preflight
      tests plus `semantic.rs` cosine + embed-cache-key tests exist; the end-to-end
      lexical+semantic blend still lacks a dedicated combination test.

### Strategic / differentiators (what makes it amazing)

- [ ] **OAuth client registration + per-client server scoping.** A client
      authenticates to Toolport, shows up in the app, you assign which servers it
      sees. Profiles already do half. This is Sigiz's explicit ask AND the proper
      long-term auth model for the HTTP bridge. The real moat. (L)
      **Partial:** per-client server scoping shipped (HTTP-bridge bearer tokens
      scoped to a profile via `resolve_http_scope`/`http_clients`, plus live
      `client_scopes` resolution); still open: OAuth-based inbound client
      registration (no authorize/register endpoint; tokens are issued manually).
- [x] **Block-on-drift / quarantine + re-approval for high-risk tools.** SHIPPED
      2026-06-30 (on main, unreleased): opt-in `quarantine_on_drift` blocks a
      high-risk drift (a poisoned definition, or a destructive tool whose definition
      changed/appeared) until the user re-approves it; detection-only stays the
      default. Settings toggle + re-approve list in the app. Auth-bearing dimension
      (drift on a credential-bearing server) deferred to a later pass.
- [ ] **Local-small-model UX.** 7B models still struggle with the lazy
      search-then-call chain (the multi-step guard helped, didn't solve). This is
      Open WebUI's core audience. (L)
- [x] **Live call-inspection in Activity** (real request/response bytes) folds MCP
      Peek's value into Toolport, since we're already on the path. (M)
- [ ] Result-shaping Tier 2: per-server fidelity policy, projection, code-execution
      handoff; end-to-end "does the model actually page" validation. (M-L)
- [x] Showcase server (`toolport-openapi-mcp`: any OpenAPI spec -> an MCP server;
      published to npm as `toolport-openapi-mcp@0.2.0`) as the funnel + a demo of
      lazy discovery + result-shaping.

**Community-requested (2026-07-03, r/LocalLLaMA launch thread):**

- [x] **Lazy-discovery search trace / observability.** Shipped (#114) as the Activity
      **Discovery** panel: every `toolport_search_tools` call records the query, the
      matched tool names, which won (top), and the ground-truth per-turn token overhead
      (returned schemas vs. the full scoped catalog, via `savings::estimate_tokens`).
      Local, bounded, tool-names-only (no args/results). The in-path angle is the
      differentiator vs. post-hoc telemetry (e.g. tokentelemetry.com), which reads
      session logs and doesn't break out MCP tool-schema overhead. Follow-ups still open:
      per-candidate scores (lexical + semantic blend) and the exact returned input
      schema, not just names. (M, core done)
- [x] **Pinned / prerequisite tools in search (`tool_prereq`).** Let a tool be marked so
      it's always returned (with its schema) regardless of match score - for tools that
      are a hard prerequisite (auth/list-before-act) or whose description doesn't match
      the user's query keywords, so lazy discovery never hides a load-bearing tool.
      Fits alongside tool overrides (same per-tool config surface). Suggested by kevrex5,
      who built the same pattern. (S-M) **SHIPPED (#126)** as the PlaygroundView pin toggle.
- [x] **Client support: pi coding agent. SHIPPED (#128):** requested on the launch thread
      ("a lot of users here use pi for local agent coding"). Registered pi as a
      `JsonMcpServers` client writing its Pi-owned global config at `~/.pi/agent/mcp.json`
      (home-anchored), mirroring the Cursor/BoltAI writers. Bound for the next release.
- [ ] **Two-layer / hybrid tool search (the "Zillow isn't near 'house'" miss).** Suggested
      by MajMin5 (r/LocalLLaMA), who independently built the same lazy loader and validated
      the pattern. Pure semantic (embedding) search misses tools whose name/description
      doesn't embed near the query even though the association is common knowledge (search
      "home information" → embeddings skip a `zillow` tool). His fix was a slow LLM fallback
      (ask a small model "which of these tools fit <task>?"). Our cheaper version: (a) a
      genuine **hybrid ranker** (lexical/BM25 blended with the existing semantic score, not
      semantic-alone), and (b) **broaden the candidate set when top scores are low-confidence**
      so the (already capable) calling model can reason over descriptions instead of us
      hiding them. Optionally a `search_tools_deep` meta-tool that returns more candidates +
      full descriptions. No mandatory local model — the client model IS the reasoning layer.
      Ties into the open "per-candidate lexical+semantic scores" search-trace follow-up. (M)
      **Shipped:** the hybrid lexical+semantic ranker scores every doc, and SOU-161 adds a
      normalized confidence signal plus bounded, server-diverse fallback candidates for weak
      and zero-match searches. Exact/high-confidence searches stay compact. A separate fifth
      meta-tool remains intentionally deferred unless recall benchmarks prove it necessary.
- [ ] **Per-client discovery mode + raw/direct passthrough.** Also from MajMin5: clients that
      already do their own tool-gating/deferral (Claude Desktop, LibreChat, and Claude Code's
      tool-search) pay a wasteful double hop when forced through our meta-tools (load meta-tools
      → search → load tool → call) versus just seeing the tools directly and using their native
      logic. Today `lazy_discovery` is a single **global** bool in the registry (registry.rs);
      make it **per-client** (and consider auto-defaulting self-managing clients to the direct
      catalog, weak/local models to lazy). This is the client-agnostic story finished: one
      place to configure servers, right discovery surface per client. (His stdio→HTTP + mobile
      asks we already cover — the gateway speaks HTTP/OpenAPI natively.) (M)
      **Partial:** raw/direct passthrough shipped (discovery modes full/lazy/grouped via
      `resolve_discovery_mode`), and mode can be set per client through the
      `CONDUIT_DISCOVERY` env var; still open: a per-client discovery field in the
      registry (it is still a single global setting) and auto-defaulting self-managing
      clients to the direct catalog.

## Robustness sprint (2026-07-04, "nothing fails silently")

A 3-surface completeness/edge-case audit (app UX, gateway runtime, Teams). **SHIPPED
on branch `robustness-sprint`:** downstream **re-spawn on the breaker's half-open probe**
(a crashed stdio child no longer stays dead until a full registry rebuild; self-heal
only fired when EVERY server was down); **Playground call timeout + Cancel + elapsed**
(the one true hang with no escape); **ConfirmDialog on the two credential-deleting
actions**; **Catalog live-search error-vs-empty** with retry; **embeddings HTTP timeout**
(a hung endpoint falls back to lexical, no stalled search); **bounded stdio read_line**
(a newline-less multi-GB line can't grow unbounded); **shaped-result marker honesty**
(no more "Nothing was lost" over-promise; says held-temporarily + re-run on expiry);
**tool-cache `{version, tools}` versioning** (stale cache from an old build is discarded);
and the whole **Teams removed-member/role/auto-sync** fix (new server `GET /me` heartbeat,
removed members actually disconnect locally, role refreshes every sync, app-level 5-min
background sync so policy reaches every member; deployed server-side).

**Still open from the audit (not yet built):**

- [x] **Slowloris read timeout on the HTTP bridge:** a bounded ingress adapter enforces
      absolute header/body deadlines before handing complete requests to `tiny_http`,
      with a 64-connection cap on incomplete reads and direct 408 responses.
- [ ] **Persist OAuth token expiry.** `authenticate_oauth` parses `expires_in` then drops
      it (`oauth.rs`), so no "re-auth soon" UX is possible. Store issue/expiry ts; then a
      subtle near/past-expiry hint on the server row (probe stays source of truth). (M)
- [ ] **Post-connect success signal for first-timers** ("Toolport is now serving N servers
      to <client>; open it and ask for tools"). The other half of this item, onboarding's
      Done step surfacing probe failures instead of swallowing them to `health=[]`, shipped
      in #186. (M -> S remaining)
- [x] **Playground empty/auth states** (#184): explicit "server advertises no tools" copy;
      auth-required connect failures link to the server's Secrets dialog (auth-error matcher
      widened for inflected forms). Residual: label the raw-JSON fallback when a schema is
      too complex to form-render.
- [x] **Settings status panels** distinguish stale-from-poll-failure vs empty (#185): the
      HTTP-bridge, quarantine (15s), and allowed-tools (10s) polls no longer swallow errors,
      they flag "couldn't read / may be stale" instead of rendering as empty.
- [ ] **Client-import preview**: `handleImport` bulk-adds every importable server with only
      a count toast; reuse the share-link `preview_import`/`ImportItem` review flow. (S-M)
- [x] **Recall escape hatch for lazy discovery (SOU-161).** Weak or zero-match searches now
      preserve ranked results and add a bounded, server-diverse recovery menu. The response
      explicitly names the existing empty-query-with-server exhaustive listing. This stays
      inside `toolport_search_tools`, preserving the four-tool default surface; a dedicated
      fifth meta-tool is deferred unless recall benchmarks show it is needed.
- [ ] **Integrity-file cross-process lock.** `tool-pins.json` / `tool-quarantine.json` are
      atomic-write but unlocked; two gateways detecting drift at once can clobber each
      other's quarantine set (a lost entry un-blocks a tool). Reload-under-lock or centralize
      writes in the app. Security-adjacent sibling of the deferred registry cache-coherence. (M)
- [ ] **Deterministic tool-collision suffixes.** `exposed_name` `_2/_3` depends on add
      order; a removed-then-readded server can take a different slot and silently rename a
      tool the client cached, failing in-flight calls with "no route". Derive from
      `(server_id, tool_name)` content instead of position. (M)
- [x] "Clear filter" buttons on zero-match states (Activity recent-calls, Playground tool
      filter, catalog search) shipped in #184. Residual: light credential/raw-arg
      client-side validation. (S)

## The core decision: Toolport is a gateway, not a file editor

A tool that only edits each client's MCP JSON config is a dead end:

1. Clients are migrating servers out of the JSON file into UI-managed,
   account-synced connectors (Claude already has). The JSON file is emptying.
2. Editing a config file requires restarting the client for changes to take
   effect, so "toggle a server on/off without reloading the app" is impossible
   with the file-editor approach.

Toolport instead runs a **local MCP gateway**. Each client points at Toolport
once (as a local stdio server and/or a custom connector URL). Toolport holds the
real registry of servers and routes to them. This unlocks the headline win and
flips every weakness:

- **~90% fewer tokens.** In lazy-discovery mode the gateway advertises 4 meta-tools
  instead of every server's full tool list, so the agent's context stays flat no
  matter how many servers you connect. Measured: 99.5% less tool-definition overhead
  per request on a 415-tool catalog (see [BENCHMARK.md](../BENCHMARK.md)).
- **Hot toggle, no restart.** Enable/disable a server, the gateway re-emits its
  tool list via the MCP `notifications/tools/list_changed`; supporting clients
  update live. The client's own config never changed, so nothing reloads.
- **No plaintext secrets in client configs.** The gateway holds keys in the OS
  keychain and injects them at runtime. Client config only says "talk to Toolport."
- **Audit log for free.** Every tool call flows through the gateway. That log is
  the governance/MSP product.
- **Routes around the connector migration.** Toolport registers as one custom
  connector in Claude; all managed servers appear through it.

## Spike findings (2026-06-18)

### Spike 42: can we read Claude's connectors from disk? (Partially, but fragile)

- Claude Desktop's `claude_desktop_config.json` `mcpServers` is **empty** on this
  machine. All servers moved to connectors.
- Connectors + OAuth tokens live in `%APPDATA%\Claude\config.json` as
  **DPAPI-encrypted** blobs (Chromium safeStorage, `v10` prefix). Not readable.
- Connector _names_ (Clerk, GitHub, Pax8, revenuecat, Supabase, Vercel, Stripe,
  expo) DO appear in plaintext in the Chromium LevelDB/IndexedDB stores for the
  `claude.ai` origin.
- BUT those stores are **locked while Claude is running**, the schema is
  undocumented Chromium IndexedDB, and the real source of truth is the user's
  Anthropic account (server-side sync), not a local file.

**Verdict:** local read-only _inventory_ of connector names is possible but
fragile and operationally awkward (locked DBs, undocumented schema, account-side
truth). It is NOT a foundation to build _management_ on. This confirms the
gateway architecture: Toolport cannot manage Claude's connectors directly, so it
becomes one connector that fans out to everything it manages. A best-effort,
read-only "connectors detected (view-only)" panel is worth showing for the
governance inventory story, clearly labeled as not-managed.

### Spikes 40 and 41 (need morning verification on running clients)

- Spike 40 (live toggle): confirm `tools/list_changed` actually refreshes the
  tool list without restart in each client. Determines how universal hot-toggle is.
- Spike 41 (Claude as connector): confirm Toolport can register as a custom
  connector / local server in current Claude Desktop and expose downstream tools.

These require driving real client UIs and were deferred (user asleep; not safe to
mutate their live client setup unattended).

## Build order

Phase 0 - Foundation

- [x] Tauri + React + Rust scaffold, 0 vulns
- [x] Client adapter readers (import/discovery): detect clients, parse JSON/TOML
- [x] Toolport registry: own source-of-truth store (servers, profiles, enabled)
- [x] Profiles: named server sets, switchable
- [x] Write-back adapters with auto-backup (fixture-tested)
- [x] Frontend: profiles, toggles, import, add-server
- [x] OS keychain module for secrets

Phase 1 - The gateway

- [x] MCP stdio server (initialize, tools/list, tools/call)
- [x] Downstream MCP client: spawn/connect real servers, multiplex tools (namespaced)
- [x] Live reconfig + `tools/list_changed` on toggle (registry file watcher)
- [x] Secret injection at runtime (OS keychain via keyring; injected at spawn)
- [x] Audit log of tool calls (Activity view)
- [x] Proxy remote (http/sse) downstream servers, not just stdio
- [x] Self-heal: rebuild router on a call when no servers are connected
- [x] Tool-name sanitizing (clients drop hyphenated names) + cache-poisoning guard

Phase 1.5 - Remote auth

- [x] Token auth: vault a bearer token per http server, injected by gateway
- [x] OAuth 2.1 flow: discovery + DCR + PKCE + loopback + exchange
- [x] OAuth token refresh on 401/expiry
- [x] Auth UX: auto-probed status badges, one-click authenticate (OAuth + key),
      vendor hints, live propagation to connected clients

Phase 2 - Client integration

- [x] "Install Toolport into client X" (surgical, backs up, preserves others)
- [x] Uninstall (surgical remove)
- [x] Client detail reframed as connect + import sources
- [x] Migrate-on-connect: import a client's servers, leave it gateway-only
- [x] Live propagation (registry mtime bump -> gateway rebuild -> tools/list_changed)
- [x] Registry path anchored to a non-virtualized home path (MSIX desync fix)
- [x] Bundle toolport-gateway as a sidecar so the installed path survives in
      production (externalBin via merge config `tauri.bundle.conf.json`, staged by
      `scripts/prepare-sidecar.mjs`; `resolve_gateway_path` finds the dev name or
      the packaged `-<triple>` name). Shipping in signed releases.

Phase 3 - Scaling & UX

- [x] Lazy discovery: `CONDUIT_DISCOVERY=lazy` exposes 4 core meta-tools (status/search/call/fetch)
- [x] Per-agent scoping: `CONDUIT_PROFILE` + per-client profile picker, per-profile cache
- [x] Catalog: curated popular set + live official MCP Registry search, type-ahead
- [x] Catalog as a left-nav destination; status grouping; non-blocking UI commands

## Next (tiered)

Tier 2 - feature completeness (in progress)

- [x] Per-tool enable/disable + destructive-tool deny-list (UI toggles; gateway
      hides+blocks; global destructiveHint switch)
- [x] Tool playground: invoke any tool from the app and see the result
- [x] Proxy resources + prompts (capability-gated discovery, namespaced prompts,
      uri-routed resources); sampling / elicitation passthrough shipped for stdio downstream
- [x] Observability: per-server latency (avg/p95), success/error rates, per-tool
      breakdown, and server/errors-only filters (Activity dashboard)
- [x] Tool-definition integrity / rug-pull detection: fingerprint tools on connect,
      diff on every refresh, flag changed/added definitions on already-approved
      servers as a security notice (detection only, on by default). Reuses the
      existing tools/list_changed refresh hook. See `docs/specs/mcp-integrity.md`.
- [x] Security: tool-description injection scanning (poisoning / line jumping),
      folded into the integrity pass.
- [x] Semantic tool search (optional, off by default): blend embedding similarity
      into the lexical ranker so paraphrased needs surface the right tool. Pluggable
      `/v1/embeddings` endpoint, disk-cached, lexical fallback. Recall measured by
      `benchmark/retrieval.mjs`. See `docs/specs/semantic-search.md`.
- [x] Content defense (agentjacking): scan untrusted tool _results_ for injection and
      wrap flagged content with a "data, not instructions" provenance marker before the
      agent sees it. Detection + labeling, never blocks, on by default. See
      `docs/specs/content-defense.md`.
- [ ] Security, next: a Security page mapping Toolport's controls to the MCP attack
      taxonomy; opt-in lossy result shaping / dangerous-call gating (content-defense Tier 2).

Tier 3 - launch prep

- [x] Bundle the gateway sidecar; signed/notarized macOS installers (Win/Linux
      unsigned with documented bypass); cargo-audit in CI.
- [x] Verify macOS / Linux (signed mac dmgs arm64 + Intel, Linux deb/AppImage;
      tested across Windows/macOS/Ubuntu VMs)
- [x] Marketing site (toolport.app) with demo video.
- [x] In-app auto-updater (Tauri v2 updater plugin + signed `latest.json` from the
      release pipeline). Live from v0.3.3 onward.
- [x] First-run onboarding wizard (detect clients, add servers, connect a client).
- [x] macOS keychain access-group entitlement (app + gateway share secrets with
      no "Always Allow" prompt) - shipped v0.9.3
- [x] Launch: Product Hunt, MCP registries (Glama/mcp.so/awesome-mcp listed)

Tier 4 - teams / enterprise (paid)

- [x] Hosted control plane + shared/synced config (Teams, launched 2026-07-08:
      teams.toolport.app, join-code onboarding, long-poll config + policy sync).
      Remote/self-hosted gateway shipped headless in v1.6.0 (Docker + streamable HTTP).
- [ ] RBAC / SSO
- [x] Org policy engine (mandated approval gates; tighten-only content-defense +
      quarantine-on-drift) and audit export (30-day exportable trail).
- [ ] Org-level per-tool allow/deny (beyond the local destructive deny-list)
- [ ] Secret-vault integrations (1Password, Vault, cloud secret managers)

## Security invariants (do not regress)

- Backend never sends secret _values_ to the UI; env var names only.
- Secrets live in the OS keychain, never in Toolport's registry file or any
  client config.
- Snapshot every client config before modifying it; modifications are reversible.
- Never read or decrypt another app's OAuth tokens.

## Strategic idea: Toolport Full-API Servers (curated OpenAPI catalog)

A curated catalog of MCP servers generated from OpenAPI specs that expose the COMPLETE API
of services whose official MCP is read-only / partial / missing (e.g. Stripe's official MCP
is read-only; a full one can create prices, payment links, everything).

**Why only Toolport does this well:** a complete-API server is 100s-of-tools huge and would
blow up any agent's context — which is why nobody ships one. Lazy discovery (4 meta-tools +
search-on-demand, flat context) is the one thing that makes it usable. This reframes lazy
discovery from "saves tokens" to "unlocks otherwise-impossible servers." Plus Toolport's
governance (HITL + destructive-tool gating) is what makes handing an agent a full billing
API _safe_ — safety is the selling point, not a risk.

**Already built:** `toolport-openapi-mcp` (OpenAPI→MCP; Stripe spec = 587 tools), secret
injection, OAuth, curated catalog. New work = per-service CURATION (clean tool names/descs,
grouping, auth config), publish, catalog entries, maintenance.

**Dependency (important):** this makes search recall load-bearing — a 587-tool server is only
as good as the search that surfaces the right tool. Ties directly to the hybrid-search +
recall-escape-hatch items above; do those alongside.

**Start:** Stripe first (weak official MCP, high-value API, killer demo). Then Linear/Notion/
Shopify/Twilio. Position: "the official X MCP only reads; Toolport's does everything X's API
can — governed, and without bloating your context."
