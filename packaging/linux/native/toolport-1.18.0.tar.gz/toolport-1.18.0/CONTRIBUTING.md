# Contributing to Toolport

Thanks for your interest. Toolport is a local-first MCP gateway and manager: a
Tauri desktop app (Rust backend + React/TypeScript frontend) plus a separate
`toolport-gateway` binary that AI clients spawn.

Want to ask a question, float an idea, or talk through a change before you build
it? Join the [Discord](https://discord.gg/Xsn27MxdBA). New contributors welcome,
and we merge community PRs regularly.

## Quick start

Requires Node 20+ and the Rust toolchain.

```bash
npm install
npm run build:gateway   # build the gateway binary (clients spawn it; needed when running from source)
                       # uses --no-default-features to skip Tauri/WebKit for a fast compile
npm run tauri dev       # run the desktop app
```

**Dev data directory:** debug builds (`tauri dev`, `cargo build` without `--release`)
use a separate data dir — `%APPDATA%\\Roaming\\Toolport-dev` on Windows,
`~/.config/Toolport-dev` on Linux/macOS — so development never touches your
installed release data. Override with `TOOLPORT_DATA_DIR` (legacy: `CONDUIT_DATA_DIR`)
for headless tests.

On macOS/Linux, see the platform notes in the [README troubleshooting](README.md#troubleshooting).

## Development workflow

### What hot-reloads vs what needs a rebuild

| You changed                                              | What happens                                                                                                                                |
| -------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| React/TS frontend (`src/`)                               | Vite hot-reloads instantly — no restart needed                                                                                              |
| Rust backend (`src-tauri/src/`)                          | `npm run tauri dev` recompiles and restarts the app automatically                                                                           |
| Gateway binary (`src-tauri/src/bin/toolport-gateway.rs`) | **Not rebuilt by `tauri dev`.** Run `npm run build:gateway` after changes, then restart any connected clients so they re-spawn the gateway. |

The gateway is a separate binary that AI clients spawn as a subprocess. Packaged
releases bundle it, but when running from source you must build it manually:

```bash
npm run build:gateway   # one-time, or after gateway code changes (--no-default-features)
```

If a client reports the gateway "was not found," you forgot this step.

### Running tests

```bash
# Backend (Rust: library, binaries, and integration tests)
npm run test:rust

# Headless gateway security smoke (Node source of truth; build gateway first)
npm run build:gateway
npm run smoke:headless

# Windows PowerShell mirror
powershell -ExecutionPolicy Bypass -File scripts/smoke-headless.ps1

# Frontend unit tests (Vitest)
npm run test

# Windows installer script (Pester 5, Windows only)
npm run test:install-script

# Frontend type-check + build
npx tsc --noEmit && npm run build
```

The Rust suite includes unit tests in each module (`clients`, `catalog`,
`registry`, `router`, `oauth`, etc.), binary-target tests, and integration tests
in `src-tauri/tests/`. Use the npm script above so your local target selection
matches CI. Frontend tests use [Vitest](https://vitest.dev) and live alongside
the code as `*.test.ts` or `*.test.tsx` files inside `src/`, depending on whether
the test contains JSX.

### Run the smallest loop your change needs

`npm run test:rust` builds with the `desktop` feature, which pulls Tauri and
(on Linux) WebKitGTK: **528 crates against 288 without it**. On a laptop or a
default 32G Codespace that is the difference between a build that finishes and
one that fills the disk. Most changes do not need it.

**Frontend only** (anything under `src/`, including every panel in
`ActivityView.tsx` and `SettingsView.tsx`) needs no Rust build at all:

```bash
npm run test          # vitest
npm run lint
npx tsc --noEmit
```

**Rust outside `src-tauri/src/desktop.rs`** runs with the desktop feature off,
which is also exactly what CI runs:

```bash
cargo test --manifest-path src-tauri/Cargo.toml --no-default-features --lib
cargo test --manifest-path src-tauri/Cargo.toml --no-default-features --lib clients
```

A filter runs a different subset than the full suite does, which can expose test
interference the whole run happens to avoid. If a filtered run fails, re-run the
named test on its own before assuming your change caused it, and check whether
it also fails on `main` (SBS-904 is one such case).

**Only `desktop.rs` itself needs the full build.** That module is
`#[cfg(feature = "desktop")]`, so a test you add there does not run under
`--no-default-features` and therefore **does not run in CI either**, since every
Rust job there passes that flag. If the logic you are fixing has no Tauri
dependency (file reads, string formatting, path resolution), prefer moving the
core into the module that owns it (`gatewaylog`, `registry`, `clients`, ...) and
leaving a thin caller in `desktop.rs`. That makes it testable in the light loop
and gets it CI coverage it would otherwise never have.

If `target/` is still too large, `--lib` alone beats `--lib --bins --tests`,
`cargo clean -p conduit` drops just this crate's artifacts, and
`CARGO_TARGET_DIR=/some/other/volume` moves the whole thing off a full disk.

### Let CI do the verifying

CI runs the full matrix on **every pull request**, including the platforms most
contributors do not have. You do not need a clean local run before opening one:
push a draft PR and iterate on what CI reports. That is the intended path when
your machine cannot build the whole project, and it is never treated as a lower
grade of contribution.

The GitHub required check is still named **Build + test**. That name is a
merge gate over the Linux suite, the headless Rust matrix (the Windows
keyring tests live on `windows-latest`), and the `install.ps1` Pester job
(SBS-874). Clippy stays non-blocking until existing warnings are cleared.
Adding the individual job names as separate required contexts is a GitHub
settings click; it is not something a workflow file can do.

`scripts/install.ps1` is the `irm ... | iex` one-liner, so a regression in asset
selection, checksum enforcement, or the silent-install flag reaches users with no
build step in between. `scripts/install.Tests.ps1` drives the real script end to
end with the GitHub API, the download, and the installer mocked. It needs
[Pester](https://pester.dev) 5.5 or newer, which is not the version bundled with
Windows PowerShell 5.1:

```powershell
Install-Module Pester -MinimumVersion 5.5.0 -Force -Scope CurrentUser -SkipPublisherCheck
```

`Get-FileHash` is deliberately left unmocked there: the download mock writes known
bytes and the fake release advertises their real digest, so a checksum test fails
if verification is ever skipped or inverted. Keep it that way when adding cases.

### Formatting

Prettier enforces consistent formatting across the frontend and docs. The CI
checks this on every PR, but you can fix issues locally before pushing:

```bash
npm run format        # format all files in place
npm run format:check  # check only (fails without writing — same as CI)
```

**Do not run `cargo fmt`.** The Rust tree is deliberately not rustfmt-clean and
there is no fmt gate in CI, so `cargo fmt` currently rewrites roughly 850
places across every Rust file in the project. That buries your actual change in
unrelated reflow, and it conflicts with every other open PR touching the same
file. Match the style of the code around you, and leave the rest alone.

If your editor formats Rust on save, turn it off for this repo:

```jsonc
// .vscode/settings.json
{ "[rust]": { "editor.formatOnSave": false } }
```

If a review asks you to drop a formatter run, `git checkout main -- <file>` and
re-applying your change by hand is usually faster than unpicking the diff.

### Linting

ESLint catches code-quality issues and React anti-patterns. The CI runs it on
every PR:

```bash
npm run lint        # check
npm run lint:fix    # auto-fix what it can
```

Warnings are non-blocking. If you see a `react-hooks/set-state-in-effect`
warning, it's usually the standard Tauri pattern of loading data from the Rust
backend in a `useEffect` — review it for unnecessary re-renders, but it won't
block the build.

### Rust linting

Clippy checks the Rust backend and gateway binary. CI runs it on every PR.

```bash
cargo clippy --manifest-path src-tauri/Cargo.toml --lib --bins
```

Clippy warnings are currently non-blocking. The CI gate will be made blocking
after the existing warnings have been cleared.

### Git hooks (pre-commit)

When you run `npm install`, Husky installs a pre-commit hook that automatically
formats staged files with Prettier and auto-fixes lint errors with ESLint. This
catches formatting and lint issues before they reach CI.

If you need to bypass hooks for a specific commit (e.g., a work-in-progress
snapshot), use `git commit --no-verify` — but CI will still enforce all checks.

### Debugging

**Gateway verbose logging:** the gateway writes an always-on log (connection
lifecycle events) to a file in Toolport's data directory. Set `TOOLPORT_DEBUG=1`
(legacy: `CONDUIT_DEBUG=1`) to also capture per-request traces (tool-call arguments,
routing decisions, downstream responses). "Copy diagnostics" in the app bundles
this log with version info and a registry summary for bug reports.

```bash
TOOLPORT_DEBUG=1 npm run tauri dev
```

**Registry file:** stored at a stable per-user path (visible via "Open data dir"
in the app). The gateway watches this file and rebuilds live, so toggling a
server in the UI takes effect without restarting the client.

### Common gotchas

- **Gateway "not found" when running from source.** `npm run tauri dev` builds
  the app but not the gateway sidecar. Run `npm run build:gateway` once (and
  again after any change to `toolport-gateway.rs`).

- **macOS keychain prompts in dev.** An unsigned dev build gets an unstable
  code-signing identity, so the keychain re-prompts or denies reads. A signed
  release fixes this.

- **Linux: secrets fail without a keyring.** Secret storage uses the freedesktop
  Secret Service (libsecret). A headless box or a session without a running
  keyring daemon has nowhere to store secrets. Run in a desktop session with
  GNOME Keyring or KWallet unlocked.

For end-user troubleshooting (OAuth, AppImage, VS Code), see the
[README troubleshooting section](README.md#troubleshooting).

## Layout

- `src/` - React/TypeScript frontend (the app UI).
- `src-tauri/src/` - Rust backend:
  - `lib.rs` - Tauri commands (the bridge between UI and backend).
  - `registry.rs` - the server/profile registry (Toolport's source of truth).
  - `clients.rs` - detecting and editing AI client configs.
  - `downstream.rs` - talking to MCP servers (stdio + http transports).
  - `router.rs` - aggregating tools/resources and routing calls.
  - `oauth.rs` / `secrets.rs` / `remote.rs` - auth and the OS keychain.
  - `catalog.rs` - the curated + registry server catalog.
  - `bin/toolport-gateway.rs` - the gateway binary clients connect to.

## Before you open a PR

Run the [tests described above](#running-tests). Please match the surrounding
style: the code favors small, well-commented functions that explain the _why_.
Keep comments at the density of the file you're editing.

## Good places to start

- New curated catalog entries (real, verified MCP servers) in `catalog.rs`.
- New curated stacks (role-based server bundles) in `stacks.rs`.
- Additional client support in `clients.rs` (a new AI tool's config format).
- Frontend polish: empty states and error messages.
- Tests for any of the above.

## Adding a curated catalog entry

The catalog is a hand-verified list of popular MCP servers in
`src-tauri/src/catalog.rs`. Each entry becomes a one-click "Add" button in the
browse view. Two helpers cover every case:

### Remote (HTTP/SSE) servers

Use the `http()` helper inside `curated()`:

```rust
http("My Service", "What it does, in one line.", "https://mcp.example.com/mcp", "https://example.com/docs"),
```

That's it — the URL is the server endpoint. Most hosted MCPs use streamable-http.

### Local (stdio) servers

Use the `cmd()` helper:

```rust
cmd("My Tool", "What it does.", "npx", &["-y", "@scope/package-name"], &["API_KEY"], "https://github.com/org/repo"),
```

- `command` — the executable (`npx`, `uvx`, `node`, etc.)
- `args` — passed as-is to the command
- `env` — **names only** (e.g. `&["API_KEY"]`). Values are vaulted in the OS
  keychain at runtime; never hardcode them here. An empty `&[]` means no auth.
- `homepage` — link to docs/source so users can learn more

### After adding the entry

1. **Add a category** in `category_for()` so the entry groups correctly in the
   browse view (e.g. `"Databases"`, `"Search & knowledge"`). Entries without a
   category appear flat in search.

2. **Add credential guidance** (optional) in `credentials_for()`. This powers the
   guided "go get your creds" step. Return `(url, hint)` where `url` is a direct
   link to the provider's token page, or `""` if there's no single page (OAuth,
   connection strings, or no auth). Return `None` if you have no guidance.

3. **Verify it runs.** Add the server in the app (or via the catalog search) and
   confirm it connects and exposes tools. If it needs an API key, enter one and
   check the probe succeeds.

4. **Run the tests:**

```bash
cargo test --manifest-path src-tauri/Cargo.toml catalog
```

The catalog tests verify every curated entry has a non-empty name, a valid
target (URL or command), and a browse-view category — your new entry will be
checked automatically.

**Reference PR:** [#19](https://github.com/tsouth89/toolport/pull/19) (Firecrawl
catalog entry — a single `cmd()` line + category).

## Adding a curated stack

Stacks are role-based bundles of catalog servers a user can set up in one flow
(e.g. "Full-stack web dev", "Founder / indie SaaS"). They live in
`src-tauri/src/stacks.rs` as an ordered list of catalog entry names, resolved
against `catalog::curated()` at runtime.

This is one of the easiest first contributions: you only need names that already
exist in the catalog. Do **not** add new catalog entries here — that is a
separate change (see [Adding a curated catalog entry](#adding-a-curated-catalog-entry)).

### 1. Pick servers that already exist

Each stack references servers by their exact `catalog::curated()` **name**
(e.g. `"GitHub"`, `"Linear"`, `"Notion"`). A mistyped name is silently dropped
when the stack is built, so the unit tests below are the tripwire.

Browse `src-tauri/src/catalog.rs` (or the in-app catalog) for available names.
Only use servers already in `curated()`.

### 2. Add a `StackDef` in `stack_defs()`

Append a definition inside `stack_defs()` in `src-tauri/src/stacks.rs`:

```rust
StackDef {
    id: "project-ops",            // stable kebab-case id
    name: "Project & knowledge",  // display name in the UI
    description: "Track work and docs across issues, wiki, and chat.",
    server_names: &["Linear", "Notion", "Slack", "Todoist"],
},
```

- `id` — stable kebab-case identifier (used in tests and UI keys)
- `name` / `description` — shown in the catalog stacks view
- `server_names` — exact catalog names, in the order they should appear

You do **not** need to update any hardcoded server-count total; the tests derive
expected resolution from `stack_defs()` itself.

### 3. Verify

```bash
cargo test --manifest-path src-tauri/Cargo.toml stacks
npm run tauri dev   # stacks show up in the catalog view
```

`every_stack_resolves_all_its_servers` fails with the stack id and the missing
server name if a reference does not resolve.
`stack_servers_carry_credential_hints_where_expected` still covers credential
hints on known token-based entries.

## Adding a new client

Clients are AI tools that store MCP server configs on disk. Toolport detects each
client, reads its servers, and can install/write the gateway entry. All of this
is in `src-tauri/src/clients.rs`.

### 1. Identify the format

Check the client's config file and match it to a `Format` variant:

| Format                  | Config shape                                                   | Existing clients                                 |
| ----------------------- | -------------------------------------------------------------- | ------------------------------------------------ |
| `JsonMcpServers`        | `{"mcpServers": {...}}`                                        | Claude Desktop, Cursor, Devin Desktop, Devin CLI |
| `JsonCopilotMcpServers` | `{"mcpServers": {...}}` entries require a `tools` allowlist    | GitHub Copilot CLI                               |
| `JsonDroidMcpServers`   | `{"mcpServers": {...}}` every entry requires a `"type"` field  | Factory Droid                                    |
| `JsonAmpMcpServers`     | dotted top-level key `amp.mcpServers` (not a nested object)    | Amp                                              |
| `JsonMcp`               | top-level `mcp` object                                         | Crush                                            |
| `JsonQwenMcpServers`    | `{"mcpServers": {"name": {"httpUrl": "..."}}}`                 | Qwen Code                                        |
| `JsonKimiMcpServers`    | `{"mcpServers": {"name": {"transport": "sse", "url": "..."}}}` | Kimi Code                                        |
| `JsonServers`           | `{"servers": {...}}`                                           | VS Code                                          |
| `JsonOpenCodeMcp`       | `{"mcp": {"name": {"command": [...]}}}`                        | OpenCode, Kilo Code                              |
| `JsonContextServers`    | `{"context_servers": {...}}` (JSONC)                           | Zed                                              |
| `TomlMcpServers`        | `[mcp_servers.name]`                                           | Codex CLI                                        |
| `YamlExtensions`        | `extensions:` map (Goose shape: `cmd`/`envs`)                  | Goose                                            |
| `YamlMcpServers`        | `mcp_servers:` map (Hermes shape: `command`/`env`)             | Hermes                                           |
| `YamlMcpServersList`    | `mcpServers:` list                                             | Continue                                         |

If the client uses a genuinely new format, add a variant to `enum Format` and a
parse function (follow the pattern of `parse_json` or `parse_toml`).

### 2. Add the client path

```rust
// In resolve_client_config_path():
"my-client" => config.join("My Client").join("config.json"),

// In resolve_client_config_path_linux():
"my-client" => config.join("my-client").join("config.json"),

fn my_client_path() -> Option<PathBuf> {
    client_config_path("my-client")
}
```

Most clients should go through `client_config_path()` and add a match arm to both
`resolve_client_config_path()` and `resolve_client_config_path_linux()`. The
Linux resolver is separate so production paths can honor `XDG_CONFIG_HOME` and
`XDG_DATA_HOME`.

**Important:** the config file's parent directory is used as the "app installed?"
heuristic. If the parent is too broad (like `~` itself) or too narrow (only
created after first MCP use), add an entry to `install_override()`.

### 3. Register the client

Add a `ClientDef` to the `defs()` list:

```rust
ClientDef {
    id: "my-client",              // stable identifier, lowercase-kebab
    name: "My Client",            // display name
    format: Format::JsonMcpServers, // from step 1
    uses_connectors: false,       // true only for UI-managed clients (Claude Desktop)
    path: my_client_path,         // from step 2
    plugin_scan: None,            // Some(fn) only if the client has out-of-config servers
},
```

### 4. Add tests

Follow the existing conventions — at minimum:

- A registration test confirming the client appears in `defs()` with the right
  format:

  ```rust
  #[test]
  fn my_client_is_registered() {
      let d = defs().into_iter().find(|d| d.id == "my-client").unwrap();
      assert!(matches!(d.format, Format::JsonMcpServers));
      assert!((d.path)().is_some());
  }
  ```

- Path tests confirming the new match arms resolve correctly. Add the client to
  `client_config_paths_are_stable_across_platforms`, and on Linux-aware paths
  also update `client_config_paths_honor_xdg_dirs_on_linux`.

- If the config file stores broader app settings instead of only MCP servers,
  add the client to `config_is_whole_app_state()`. This records that the file is
  whole-app state and is threaded through the write paths as the `lenient` flag.
  It is a declaration of intent rather than a behavior switch today: the
  never-wipe protection (a non-empty file that won't parse is always an error,
  never silently replaced) already applies to every client regardless. See the
  comment on `read_existing_json` for the history.

- A round-trip test if you added a new `Format` variant: write servers → read
  them back → verify they match. See `json_mcpservers_round_trips` for the
  pattern.

### 5. Verify

```bash
cargo test --manifest-path src-tauri/Cargo.toml clients
npm run tauri dev   # check the client appears in the sidebar
```

**Reference PR:** [#18](https://github.com/tsouth89/toolport/pull/18) (BoltAI
client — a path resolver, one `ClientDef`, and a registration test).

## Reporting issues

Bugs and ideas are welcome in [Issues](https://github.com/tsouth89/toolport/issues).
For security problems, see [SECURITY.md](SECURITY.md) (report privately, please).

## License

By contributing you agree your contributions are licensed under the repository's
[MIT license](LICENSE), which is and will remain the license for this repo (the
app and gateway). Toolport is open-core: the separate commercial Toolport Teams
server, under its own license, is what funds this free and open core.
