import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Copy,
  Download,
  FileText,
  KeyRound,
  Link2,
  Loader2,
  Plus,
  ShieldCheck,
  Sparkles,
  Store,
  Users,
  Waypoints,
  Workflow,
} from "lucide-react";
import { toast } from "sonner";
import { toastError } from "@/lib/toast";
import {
  addCatalogServer,
  getAuditLog,
  importServers,
  installGateway,
  listStacks,
  previewImportServers,
  teamConnect,
  teamJoinPoll,
} from "@/lib/api";
import { ClientLogo } from "@/components/ClientLogo";
import { clientRestartHint } from "@/lib/clientConnect";
import { HOSTED_TEAMS_URL, TEAMS_MARKETING_URL, teamUrlError } from "@/lib/teamUrl";
import { Input } from "@/components/ui/input";
import {
  importableServers,
  isGatewayServer,
  type AuditEntry,
  type DetectedClient,
  type ImportItem,
  type ProbeResult,
  type Registry,
  type Stack,
} from "@/lib/types";
import { openExternal } from "@/lib/openUrl";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { ImportReviewDialog } from "@/components/ImportReviewDialog";
import { Skeleton } from "@/components/ui/skeleton";

interface Props {
  /** Step to open at (0 = Welcome). Used to resume mid-flow. */
  initialStep?: number;
  clients: DetectedClient[];
  registry: Registry;
  onRegistryChange: (registry: Registry) => void;
  /** Re-detect clients after a connect, so their status reflects reality. */
  onClientsRefresh: () => void;
  /** Hand off to the catalog; the wizard resumes at the Connect step on return. */
  onBrowseCatalog: () => void;
  /** Probe server health for the Done step (returns per-server results). */
  onProbe: () => Promise<ProbeResult[]>;
  /** Close the wizard and open the Playground (the in-app verify fallback). */
  onOpenPlayground: () => void;
  /** Close the wizard and open Agent rules, for someone who came for that and not MCP. */
  onOpenRules: () => void;
  /** Mark onboarding complete (skipped or finished) and close. */
  onFinish: () => void;
}

/** First-run wizard. Shown only on a genuinely fresh setup (no servers, no
 * client connected) and skippable at every step. It drives the existing
 * import / connect / catalog flows so a new user reaches "my tools share these
 * servers" without hunting through the UI. */
export function Onboarding({
  initialStep = 0,
  clients,
  registry,
  onRegistryChange,
  onClientsRefresh,
  onBrowseCatalog,
  onProbe,
  onOpenPlayground,
  onOpenRules,
  onFinish,
}: Props) {
  const [step, setStep] = useState(initialStep);
  /**
   * Which door the user came through (SBS-826).
   *
   * Toolport's first run used to assume MCP: the second step was "add a server", so someone
   * who installed it to sync their agent rules had to add an MCP server they did not want, or
   * bail. `rules` drops that step. Both paths still run client detection, because connecting a
   * client is what makes either feature do anything.
   */
  const [path, setPath] = useState<"mcp" | "rules">("mcp");
  // A team member who was handed an invite code shouldn't have to click through
  // the solo flow to find a place to enter it. This branch drops them straight
  // into the join step and, on success, the team's servers arrive locally.
  const [joining, setJoining] = useState(false);

  const present = clients.filter((c) => c.appPresent);
  const importable = new Set(
    clients.flatMap((c) =>
      importableServers(c, registry).map((s) => s.name.toLowerCase()),
    ),
  ).size;
  // Live progress, so the final step reflects what the user actually did.
  const serverCount = registry.servers.filter((s) => !isGatewayServer(s)).length;
  const connectedCount = clients.filter((c) => c.gatewayInstalled).length;

  const welcome = (
    <Welcome
      key="welcome"
      present={present}
      onChoosePath={(chosen) => {
        setPath(chosen);
        setStep(1);
      }}
      onJoinTeam={() => setJoining(true)}
    />
  );
  const connect = (
    <ConnectClients
      key="connect"
      present={present}
      onConnected={onClientsRefresh}
      onNext={() => setStep(path === "rules" ? 2 : 3)}
    />
  );
  const done = (
    <Done
      key="done"
      path={path}
      registry={registry}
      clients={clients}
      serverCount={serverCount}
      connectedCount={connectedCount}
      onProbe={onProbe}
      onOpenPlayground={onOpenPlayground}
      onOpenRules={onOpenRules}
      onFinish={onFinish}
    />
  );

  // The rules path has no "add a server" step, so the array is shorter and the progress
  // indicator counts the steps this user will actually see rather than the MCP ones.
  const steps =
    path === "rules"
      ? [welcome, connect, done]
      : [
          welcome,
          <AddServers
            key="add"
            registry={registry}
            importable={importable}
            onImport={onRegistryChange}
            onBrowseCatalog={onBrowseCatalog}
            onNext={() => setStep(2)}
          />,
          connect,
          done,
        ];

  return (
    <Dialog open onOpenChange={(o) => !o && onFinish()}>
      <DialogContent className="gap-0 sm:max-w-md" showCloseButton={false}>
        <div className="flex flex-col gap-5 py-1">
          {joining ? (
            <JoinTeam
              onBack={() => setJoining(false)}
              onRegistryChange={onRegistryChange}
              onClientsRefresh={onClientsRefresh}
              onFinish={onFinish}
            />
          ) : (
            <>
              {steps[step]}

              <div className="flex items-center justify-between border-t pt-4">
                <div
                  className="flex items-center gap-1.5"
                  role="progressbar"
                  aria-valuenow={step + 1}
                  aria-valuemin={1}
                  aria-valuemax={steps.length}
                  aria-label={`Setup step ${step + 1} of ${steps.length}`}
                >
                  {steps.map((_, i) => (
                    <span
                      key={i}
                      aria-hidden="true"
                      className={`size-1.5 rounded-full transition-colors ${
                        i === step ? "bg-success" : "bg-muted-foreground/30"
                      }`}
                    />
                  ))}
                </div>
                {step < steps.length - 1 && (
                  <button
                    type="button"
                    onClick={onFinish}
                    className="text-xs text-muted-foreground transition hover:text-foreground"
                  >
                    Skip setup
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function StepHeader({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      {/* Name the dialog from the visible step heading. Radix wires
       * aria-labelledby from DialogTitle, so the dialog is announced with the
       * current step's title (and Done's live state) instead of as an unnamed
       * dialog. asChild + span keeps the visible h2 the only heading; the
       * sr-only copy is purely the dialog's accessible name. */}
      <DialogTitle asChild className="sr-only">
        <span>{title}</span>
      </DialogTitle>
      <div className="flex size-10 items-center justify-center rounded-xl bg-success/10 text-success">
        {icon}
      </div>
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      <p className="text-sm text-muted-foreground">{children}</p>
    </div>
  );
}

function Welcome({
  present,
  onChoosePath,
  onJoinTeam,
}: {
  present: DetectedClient[];
  onChoosePath: (path: "mcp" | "rules") => void;
  onJoinTeam: () => void;
}) {
  const names = present.map((c) => c.name);
  const found =
    names.length === 0
      ? "No MCP clients detected yet, you can still add servers now and connect a client once it's installed."
      : `Found ${listJoin(names)} on your machine, ready to point at the gateway.`;
  const benefits = [
    {
      icon: Workflow,
      title: "One gateway for every tool",
      body: "Set each MCP server up once; every AI client shares it.",
    },
    {
      icon: Sparkles,
      title: "Up to 91% fewer tokens",
      body: "Your agent loads a few meta-tools instead of hundreds of schemas.",
    },
    {
      icon: ShieldCheck,
      title: "Watched for tampering",
      body: "Every server is checked for rug-pulls and prompt injection.",
    },
  ];
  return (
    <>
      <StepHeader icon={<Waypoints className="size-5" />} title="Welcome to Toolport">
        One place to set up and control every AI tool on your machine.
      </StepHeader>
      <div className="grid gap-2.5">
        {benefits.map(({ icon: Icon, title, body }) => (
          <div key={title} className="flex items-start gap-3">
            <div className="mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Icon className="size-4" />
            </div>
            <div>
              <div className="text-sm font-medium">{title}</div>
              <div className="text-xs text-muted-foreground">{body}</div>
            </div>
          </div>
        ))}
      </div>
      <p className="text-sm text-muted-foreground">{found}</p>
      {/* Two doors, because two different people install this (SBS-826). Someone here for
          rules used to be walked into "add an MCP server" and had to add one they did not
          want, or leave. Both paths still connect a client, which is what makes either
          feature reach anything. */}
      <div className="grid gap-2">
        <Button
          onClick={() => onChoosePath("mcp")}
          className="h-auto justify-start py-2 whitespace-normal"
        >
          <Waypoints className="size-4" />
          <span className="flex flex-col items-start">
            <span>Set up MCP servers</span>
            <span className="text-2xs font-normal opacity-80">
              Connect servers once and share them with every AI tool
            </span>
          </span>
        </Button>
        <Button
          variant="outline"
          onClick={() => onChoosePath("rules")}
          className="h-auto justify-start py-2 whitespace-normal"
        >
          <FileText className="size-4" />
          <span className="flex flex-col items-start">
            <span>Write rules for my agents</span>
            <span className="text-2xs font-normal text-muted-foreground">
              One set of instructions, applied to every AI tool. No MCP server needed
            </span>
          </span>
        </Button>
      </div>
      <div className="flex flex-col gap-1.5 border-t pt-4">
        <button
          type="button"
          onClick={onJoinTeam}
          className="flex items-center gap-2 text-left text-sm font-medium text-foreground transition hover:text-primary"
        >
          <Users className="size-4 shrink-0 text-muted-foreground" />
          Joining a team? Enter your invite code
          <ArrowRight className="size-3.5 shrink-0 text-muted-foreground" />
        </button>
        <button
          type="button"
          onClick={() => openExternal(TEAMS_MARKETING_URL)}
          className="self-start text-2xs text-muted-foreground transition hover:text-foreground"
        >
          What is Toolport for Teams? →
        </button>
      </div>
    </>
  );
}

/** The team-member on-ramp. A person handed an invite code lands here from the
 * Welcome step, pastes it, and the team's shared servers arrive locally. The
 * hosted server is the default; self-hosting is a tucked-away advanced toggle so
 * the common case is a single field. */
function JoinTeam({
  onBack,
  onRegistryChange,
  onClientsRefresh,
  onFinish,
}: {
  onBack: () => void;
  onRegistryChange: (r: Registry) => void;
  onClientsRefresh: () => void;
  onFinish: () => void;
}) {
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [serverUrl, setServerUrl] = useState(HOSTED_TEAMS_URL);
  const [advanced, setAdvanced] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [joined, setJoined] = useState(false);
  // Set while an approval-gated join waits for an admin; holds the values used to request it.
  const [pending, setPending] = useState<{
    serverUrl: string;
    requestToken: string;
    name?: string;
  } | null>(null);

  // Poll a pending, approval-gated join until an admin acts. A transient network error keeps
  // the wait alive; an explicit deny/expiry ends it with a message.
  useEffect(() => {
    if (!pending) return;
    let cancelled = false;
    const tick = async () => {
      try {
        const r = await teamJoinPoll(
          pending.serverUrl,
          pending.requestToken,
          pending.name,
        );
        if (cancelled) return;
        if (r.status === "connected" && r.registry) {
          setPending(null);
          onRegistryChange(r.registry);
          onClientsRefresh();
          setJoined(true);
        } else if (r.status === "denied") {
          setPending(null);
          setError("An admin declined your request to join this team.");
        } else if (r.status === "unknown") {
          setPending(null);
          setError("This join request expired. Ask for the link again and reconnect.");
        }
      } catch {
        // Transient: the next tick retries.
      }
    };
    void tick();
    const id = setInterval(tick, 4000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pending]);

  const join = async () => {
    setError(null);
    const urlError = teamUrlError(serverUrl);
    if (urlError) {
      setError(urlError);
      return;
    }
    if (!code.trim()) {
      setError("Enter the invite or connect code your team gave you.");
      return;
    }
    setBusy(true);
    try {
      const su = serverUrl.trim();
      const mn = name.trim() || undefined;
      const r = await teamConnect(su, code.trim(), mn);
      if (r.status === "pending" && r.requestToken) {
        // Approval-gated link: hold and poll (effect above) until an admin approves.
        setPending({ serverUrl: su, requestToken: r.requestToken, name: mn });
      } else if (r.status === "connected" && r.registry) {
        onRegistryChange(r.registry);
        onClientsRefresh();
        setJoined(true);
      } else {
        setError("The server returned an unexpected connect response.");
      }
    } catch (e) {
      setError(String(e));
    } finally {
      setBusy(false);
    }
  };

  if (joined) {
    return (
      <>
        <StepHeader icon={<Check className="size-5" />} title="You're on the team">
          Your team's shared servers were added to your active profile. Local and LAN
          servers stay off until you review and enable them.
        </StepHeader>
        <Button onClick={onFinish} className="self-start">
          Finish setup
          <ArrowRight className="size-4" />
        </Button>
      </>
    );
  }

  return (
    <>
      <StepHeader icon={<Users className="size-5" />} title="Join your team">
        Paste the invite code your team shared. Toolport connects this device and pulls
        the team's server set.
      </StepHeader>
      <div className="grid gap-3">
        <label className="grid gap-1 text-sm">
          <span className="text-muted-foreground">Invite or connect code</span>
          <Input
            autoFocus
            placeholder="Paste your invite or connect code"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !busy && join()}
          />
        </label>
        <label className="grid gap-1 text-sm">
          <span className="text-muted-foreground">Your name (optional)</span>
          <Input
            placeholder="e.g. Tyler"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        {advanced ? (
          <label className="grid gap-1 text-sm">
            <span className="text-muted-foreground">Team server URL</span>
            <Input
              placeholder="https://toolport.yourcompany.com"
              value={serverUrl}
              onChange={(e) => setServerUrl(e.target.value)}
            />
            <span className="text-xs text-muted-foreground">
              Only change this if your team runs its own self-hosted Toolport server.
            </span>
          </label>
        ) : (
          <button
            type="button"
            onClick={() => setAdvanced(true)}
            className="flex items-center gap-1.5 self-start text-2xs text-muted-foreground transition hover:text-foreground"
          >
            <KeyRound className="size-3" />
            Self-hosted server? Set a custom URL
          </button>
        )}
      </div>
      {error && (
        <p className="text-sm text-destructive" role="alert">
          {error}
        </p>
      )}
      <div className="flex items-center justify-between border-t pt-4">
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs text-muted-foreground transition hover:text-foreground"
        >
          <ArrowLeft className="size-3.5" />
          Back
        </button>
        {pending ? (
          <div className="flex items-center gap-2.5 rounded-lg border border-primary/40 bg-primary/5 px-3 py-2 text-sm">
            <Loader2 className="size-4 shrink-0 animate-spin text-primary" />
            <span className="text-muted-foreground">
              Waiting for an admin to approve you…
            </span>
            <button
              type="button"
              onClick={() => setPending(null)}
              className="ml-1 text-xs text-muted-foreground underline transition hover:text-foreground"
            >
              Cancel
            </button>
          </div>
        ) : (
          <Button onClick={join} disabled={busy}>
            {busy ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Users className="size-4" />
            )}
            Join team
          </Button>
        )}
      </div>
    </>
  );
}

function AddServers({
  registry,
  importable,
  onImport,
  onBrowseCatalog,
  onNext,
}: {
  registry: Registry;
  importable: number;
  onImport: (r: Registry) => void;
  onBrowseCatalog: () => void;
  onNext: () => void;
}) {
  const [busy, setBusy] = useState(false);
  const [importPreview, setImportPreview] = useState<ImportItem[] | null>(null);
  const [imported, setImported] = useState<number | null>(null);
  const [stacks, setStacks] = useState<Stack[]>([]);
  const [stacksLoading, setStacksLoading] = useState(true);
  const [stacksError, setStacksError] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [applying, setApplying] = useState(false);
  // True once the user has added a stack or imported, so "Next" replaces "later".
  const [touched, setTouched] = useState(false);

  const reloadStacks = useCallback(() => {
    setStacksLoading(true);
    setStacksError(false);
    listStacks()
      .then(setStacks)
      .catch(() => setStacksError(true))
      .finally(() => setStacksLoading(false));
  }, []);

  useEffect(() => {
    reloadStacks();
  }, [reloadStacks]);

  const have = new Set(registry.servers.map((s) => s.name.toLowerCase()));
  const stack = stacks.find((s) => s.id === selected) ?? null;

  async function doImport() {
    setBusy(true);
    try {
      const preview = await previewImportServers();
      if (preview.length === 0) {
        toast.success("No new servers found in your clients");
        return;
      }
      setImportPreview(preview);
    } catch (e) {
      toastError(`Couldn't prepare import: ${e}`);
    } finally {
      setBusy(false);
    }
  }

  async function confirmImport(selected: string[]) {
    setBusy(true);
    try {
      const next = await importServers(selected);
      onImport(next);
      setImported(next.servers.filter((s) => !isGatewayServer(s)).length);
      setTouched(true);
      toast.success("Imported servers from your clients");
      setImportPreview(null);
    } catch (e) {
      toastError(`Import failed: ${e}`);
    } finally {
      setBusy(false);
    }
  }

  /** Add every server in the chosen stack that isn't already in Toolport. */
  async function applyStack(s: Stack) {
    setApplying(true);
    const existing = new Set(registry.servers.map((x) => x.name.toLowerCase()));
    let last = registry;
    let added = 0;
    let needCreds = 0;
    try {
      for (const entry of s.servers) {
        if (existing.has(entry.name.toLowerCase())) continue;
        last = await addCatalogServer(entry);
        added++;
        if (entry.credentialsUrl || entry.envKeys.length > 0) needCreds++;
      }
      onImport(last);
      setTouched(true);
      toast.success(
        added > 0
          ? `Added ${added} server${added === 1 ? "" : "s"} from ${s.name}`
          : `${s.name}: every server is already in Toolport`,
        {
          description:
            needCreds > 0
              ? `${needCreds} need credentials. Use the "get key" links, then enable them.`
              : "Enable them next.",
        },
      );
    } catch (e) {
      toastError(`Couldn't set up ${s.name}: ${e}`);
    } finally {
      setApplying(false);
    }
  }

  return (
    <>
      <StepHeader icon={<Download className="size-5" />} title="Add your first servers">
        Pick what you work on and Toolport sets up a matching stack. You can also import
        from your other tools or browse the full catalog.
      </StepHeader>

      <div className="flex flex-col gap-3">
        {/* Role picker: each stack is a use case / role. */}
        {stacksLoading ? (
          <div
            role="status"
            aria-label="Loading starter stacks"
            className="flex flex-wrap gap-1.5"
          >
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-7 w-24 rounded-full" />
            ))}
          </div>
        ) : stacksError ? (
          <div
            role="status"
            aria-live="polite"
            className="flex items-center justify-between gap-3 rounded-md border px-3 py-2.5"
          >
            <div>
              <p className="text-sm font-medium">Starter stacks couldn't load</p>
              <p className="text-xs text-muted-foreground">
                Try again to see role-based recommendations.
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={reloadStacks}>
              Try again
            </Button>
          </div>
        ) : stacks.length > 0 ? (
          <div className="flex flex-col gap-1.5">
            <span className="text-xs text-muted-foreground">What do you work on?</span>
            <div className="flex flex-wrap gap-1.5">
              {stacks.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  aria-pressed={s.id === selected}
                  onClick={() => setSelected(s.id === selected ? null : s.id)}
                  className={`rounded-full border px-2.5 py-1 text-xs transition-colors ${
                    s.id === selected
                      ? "border-success/50 bg-success/10 text-success"
                      : "hover:bg-accent"
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {/* The recommended stack for the chosen role. */}
        {stack && (
          <div className="flex flex-col gap-2 rounded-md border bg-muted/20 p-2.5">
            <p className="text-xs text-muted-foreground">{stack.description}</p>
            <div className="flex flex-col gap-1">
              {stack.servers.map((e) => (
                <div key={e.name} className="flex items-center gap-1.5 text-[11px]">
                  {have.has(e.name.toLowerCase()) ? (
                    <Check className="size-3 shrink-0 text-success" />
                  ) : (
                    <span className="inline-block size-3 shrink-0" />
                  )}
                  <span className="font-medium text-foreground">{e.name}</span>
                  {e.credentialsUrl && (
                    <button
                      onClick={() => openExternal(e.credentialsUrl)}
                      className="text-info hover:underline"
                    >
                      get key
                    </button>
                  )}
                </div>
              ))}
            </div>
            <Button
              size="sm"
              className="self-start"
              disabled={applying}
              onClick={() => applyStack(stack)}
            >
              {applying ? (
                <Loader2 className="size-3.5 animate-spin" />
              ) : (
                <Plus className="size-3.5" />
              )}
              Add this stack
            </Button>
          </div>
        )}

        {importable > 0 && imported === null && (
          <Button variant="outline" onClick={doImport} disabled={busy}>
            {busy ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Download className="size-4" />
            )}
            Import {importable} from your clients
          </Button>
        )}
        {imported !== null && (
          <div className="flex items-center gap-2 rounded-md bg-success/10 px-3 py-2 text-sm text-success">
            <Check className="size-4" />
            Imported. Toolport now manages {imported} server
            {imported === 1 ? "" : "s"}.
          </div>
        )}

        <Button variant="outline" onClick={onBrowseCatalog}>
          <Store className="size-4" />
          Browse the full catalog
        </Button>
      </div>

      <Button variant="ghost" onClick={onNext} className="self-start">
        {touched ? "Next" : "I'll add servers later"}
        <ArrowRight className="size-4" />
      </Button>
      <ImportReviewDialog
        open={importPreview !== null}
        items={importPreview ?? []}
        busy={busy}
        onOpenChange={(open) => {
          if (!open && !busy) setImportPreview(null);
        }}
        onConfirm={confirmImport}
      />
    </>
  );
}

function ConnectClients({
  present,
  onConnected,
  onNext,
}: {
  present: DetectedClient[];
  onConnected: () => void;
  onNext: () => void;
}) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [done, setDone] = useState<Set<string>>(new Set());

  async function connect(client: DetectedClient) {
    setBusyId(client.id);
    try {
      await installGateway(client.id);
      setDone((prev) => new Set(prev).add(client.id));
      onConnected();
      // Same trap as ClientDetail (SOU-317): config is written now, but the client
      // usually only loads it on restart. Verify step also says this; put it on the
      // success toast so it is not delayed until that step.
      toast.success(`Connected Toolport to ${client.name}`, {
        description: clientRestartHint(client.name),
      });
    } catch (e) {
      toastError(`Couldn't connect: ${e}`);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <>
      <StepHeader icon={<Link2 className="size-5" />} title="Connect a client">
        Point a tool at Toolport. It connects once, then sees every server you enable
        here, no per-tool setup.
      </StepHeader>

      {present.length === 0 ? (
        <p className="rounded-md bg-muted/50 px-3 py-2 text-sm text-muted-foreground">
          No clients detected yet. Install Claude Desktop, Cursor, VS Code, or another
          supported tool, then connect it from Clients.
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {present.map((client) => {
            const connected = done.has(client.id) || client.gatewayInstalled;
            return (
              <div
                key={client.id}
                className="flex items-center justify-between gap-2 rounded-md border px-3 py-2"
              >
                <span className="truncate text-sm">{client.name}</span>
                {connected ? (
                  <span className="flex shrink-0 items-center gap-1.5 text-xs text-success">
                    <Check className="size-3.5" />
                    Connected
                  </span>
                ) : (
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-7 shrink-0 px-2 text-xs"
                    onClick={() => connect(client)}
                    disabled={busyId === client.id}
                  >
                    {busyId === client.id ? (
                      <Loader2 className="size-3.5 animate-spin" />
                    ) : (
                      <Link2 className="size-3.5" />
                    )}
                    Connect
                  </Button>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Button onClick={onNext} className="self-start">
        {done.size > 0 ? "Next" : "Skip for now"}
        <ArrowRight className="size-4" />
      </Button>
    </>
  );
}

function Done({
  path,
  registry,
  clients,
  serverCount,
  connectedCount,
  onProbe,
  onOpenPlayground,
  onOpenRules,
  onFinish,
}: {
  path: "mcp" | "rules";
  registry: Registry;
  clients: DetectedClient[];
  serverCount: number;
  connectedCount: number;
  onProbe: () => Promise<ProbeResult[]>;
  onOpenPlayground: () => void;
  onOpenRules: () => void;
  onFinish: () => void;
}) {
  // Someone who came for rules has no servers ON PURPOSE. Judging their setup by server
  // count would tell them they have not finished when they have, which is the bounce
  // SBS-826 exists to remove.
  const rulesPath = path === "rules";
  // Probe what was just added so we report the truth, not a blanket "you're set up"
  // over a server that can't actually start (a missing runtime is the #1 first-run
  // failure). Auth-pending servers are an expected next step, not a fault, so they're
  // excluded from the warning.
  const [health, setHealth] = useState<ProbeResult[] | null>(null);
  // The probe itself can fail (gateway not up yet). That's distinct from "all
  // servers healthy": swallowing it to health=[] would show a confident "you're
  // set up" over servers we never actually checked, so track it separately.
  const [probeFailed, setProbeFailed] = useState(false);
  const [probeAttempt, setProbeAttempt] = useState(0);
  useEffect(() => {
    if (serverCount === 0) {
      setHealth([]);
      setProbeFailed(false);
      return;
    }
    let alive = true;
    setHealth(null);
    setProbeFailed(false);
    onProbe()
      .then((r) => {
        if (!alive) return;
        setHealth(r);
        setProbeFailed(false);
      })
      .catch(() => {
        if (!alive) return;
        setProbeFailed(true);
      });
    return () => {
      alive = false;
    };
  }, [serverCount, onProbe, probeAttempt]);

  const nameFor = (id: string) => registry.servers.find((s) => s.id === id)?.name ?? id;
  const broken = (health ?? []).filter((r) => !r.ok && !r.authRequired);

  const configured = rulesPath
    ? connectedCount > 0
    : serverCount > 0 && connectedCount > 0;
  // The probe is about servers, and the rules path is the only way to be `configured`
  // with none. Gating the verification states on there being something to verify keeps
  // a rules finish from painting "Checking your setup" and the "Checking server
  // health…" status — a live region a screen reader announces — for servers that do
  // not exist. `health` is null on the first paint even when the effect sets it to []
  // synchronously, so without this the flash is guaranteed, not a race (SBS-826 review).
  const verifying = serverCount > 0;
  // Verification states only apply once setup is actually complete: with no client
  // connected the step reports what's missing, and must not dress the finish button
  // or the status blocks in "Checking…" / "couldn't verify" language.
  const checkingHealth = configured && verifying && health === null && !probeFailed;
  const verificationFailed = configured && verifying && probeFailed;
  const ready = configured && (!verifying || (health !== null && !probeFailed));
  // The client to verify against: the first one Toolport is actually wired into.
  const verifyClient = clients.find((c) => c.gatewayInstalled) ?? null;
  const missingParts = [
    !rulesPath && serverCount === 0 ? "added a server" : null,
    connectedCount === 0 ? "connected a client" : null,
  ].filter((part): part is string => part !== null);
  const missing = missingParts.join(" or ");
  return (
    <>
      <StepHeader
        icon={<Check className="size-5" />}
        title={
          ready
            ? "You're set up"
            : configured && checkingHealth
              ? "Checking your setup"
              : configured && probeFailed
                ? "Setup couldn't be verified"
                : "Setup started"
        }
      >
        {ready && rulesPath ? (
          <>
            Toolport is wired into {connectedCount} tool
            {connectedCount === 1 ? "" : "s"}. Write your rules once on the next screen
            and Toolport puts them in each tool&apos;s own rules file, so they all follow
            the same instructions without you editing each tool's file by hand.
          </>
        ) : ready ? (
          <>
            Toolport now manages {serverCount} server
            {serverCount === 1 ? "" : "s"} across {connectedCount} connected tool
            {connectedCount === 1 ? "" : "s"}. Toggle one on or off and your clients
            update live, no restart. Each client loads a handful of Toolport meta-tools
            instead of every downstream tool, up to 91% fewer tokens at the same task
            success. And Toolport watches every server for tampering and prompt injection,
            see Activity.
          </>
        ) : configured && checkingHealth ? (
          <>
            Toolport is checking that your servers can start before marking setup ready.
          </>
        ) : configured && probeFailed ? (
          <>
            Your servers and client are connected, but Toolport could not verify server
            health. Retry the check below or continue without verification.
          </>
        ) : rulesPath ? (
          // The MCP wording below would send a rules user to add the very thing they
          // just declined, and "do both" is wrong when only one thing is missing
          // (SBS-826 review).
          <>
            You haven't connected a client yet. Connect one any time from the main screen
            and Toolport writes your rules into that tool's own rules file. No MCP server
            needed.
          </>
        ) : (
          <>
            You haven't {missing} yet. You can{" "}
            {missingParts.length > 1 ? "do both" : "do that"} any time from the main
            screen: add or import servers, then connect a client so your tools share them.
          </>
        )}
      </StepHeader>

      {checkingHealth && (
        <div
          role="status"
          className="flex items-center gap-2 rounded-md bg-muted/40 px-3 py-2 text-xs text-muted-foreground"
        >
          <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />
          Checking server health…
        </div>
      )}

      {broken.length > 0 && (
        <div className="flex flex-col gap-2 rounded-md bg-warning/10 px-3 py-2 text-sm">
          <span className="font-medium text-warning">
            {broken.length} server{broken.length === 1 ? "" : "s"} couldn't start
          </span>
          <ul className="flex flex-col gap-1.5">
            {broken.map((r) => (
              <li key={r.serverId} className="flex flex-col gap-0.5">
                <span className="text-xs font-medium text-foreground/80">
                  {nameFor(r.serverId)}
                </span>
                {r.error && (
                  <span className="max-h-20 overflow-y-auto text-xs break-words whitespace-pre-wrap text-muted-foreground">
                    {r.error}
                  </span>
                )}
              </li>
            ))}
          </ul>
          <span className="text-xs text-muted-foreground">
            Most first-run failures are a missing runtime (Node/npx or Python/uvx) or a
            command that needs a fix. Sort it out, then retry from that server's card (the
            button below takes you to the main screen).
          </span>
        </div>
      )}

      {verificationFailed && (
        <div className="flex items-center gap-2 rounded-md bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
          <span>
            Couldn&apos;t verify your servers started, the health check didn&apos;t run.
          </span>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => setProbeAttempt((attempt) => attempt + 1)}
          >
            Retry
          </Button>
        </div>
      )}

      {ready && !rulesPath && verifyClient && (
        <VerifyCall client={verifyClient} onOpenPlayground={onOpenPlayground} />
      )}

      {rulesPath ? (
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={onOpenRules}>
            Set up agent rules
            <ArrowRight className="size-4" />
          </Button>
          <Button variant="ghost" onClick={onFinish}>
            Not now
          </Button>
        </div>
      ) : (
        <Button onClick={onFinish} className="self-start">
          {checkingHealth || verificationFailed
            ? "Continue without verification"
            : ready
              ? "Start using Toolport"
              : "Got it"}
          <ArrowRight className="size-4" />
        </Button>
      )}
    </>
  );
}

/** Proves a real call actually reached Toolport: shows a safe copy-paste prompt for the
 *  connected client, then watches the LOCAL audit log for the first new call (nothing is
 *  sent anywhere). Optional and non-blocking; Playground is the in-app fallback. */
export function VerifyCall({
  client,
  onOpenPlayground,
  pollMs = 2000,
  timeoutMs = 75_000,
}: {
  client: DetectedClient;
  onOpenPlayground: () => void;
  /** Poll interval and give-up deadline; overridable so tests run fast. */
  pollMs?: number;
  timeoutMs?: number;
}) {
  const prompt = "List the tools you can use through Toolport.";
  const [status, setStatus] = useState<
    "snapshot" | "waiting" | "success" | "timeout" | "snapshot-failed"
  >("snapshot");
  const [hit, setHit] = useState<AuditEntry | null>(null);
  const [snapshotAttempt, setSnapshotAttempt] = useState(0);

  useEffect(() => {
    let alive = true;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const deadline = Date.now() + timeoutMs;
    setHit(null);
    setStatus("snapshot");
    void (async () => {
      // Snapshot must succeed before anything can count. A failed read used to
      // leave since=0, so the next poll could celebrate retained history.
      let since = 0;
      try {
        const recent = await getAuditLog(1);
        if (!alive) return;
        if (recent[0]) since = recent[0].ts;
      } catch {
        if (alive) setStatus("snapshot-failed");
        return;
      }
      if (!alive) return;
      setStatus("waiting");
      const poll = async () => {
        if (!alive) return;
        try {
          const log = await getAuditLog(25);
          const fresh = log.find((e) => e.ts > since);
          if (fresh) {
            setHit(fresh);
            setStatus("success");
            return;
          }
        } catch {
          // Transient read error after a good baseline: keep polling.
        }
        if (Date.now() > deadline) {
          setStatus("timeout");
          return;
        }
        timer = setTimeout(poll, pollMs);
      };
      timer = setTimeout(poll, pollMs);
    })();
    return () => {
      alive = false;
      if (timer) clearTimeout(timer);
    };
  }, [pollMs, timeoutMs, snapshotAttempt]);

  async function copyPrompt() {
    try {
      await navigator.clipboard.writeText(prompt);
      toast.success("Prompt copied");
    } catch {
      toastError("Couldn't copy; select the text and copy it manually.");
    }
  }

  return (
    <div className="flex flex-col gap-2.5 rounded-md border bg-muted/20 p-3">
      <div className="flex items-center gap-2 text-sm font-medium">
        <ClientLogo id={client.id} name={client.name} size={18} />
        <span>Prove it works in {client.name}</span>
      </div>

      {status === "success" && hit ? (
        <div className="flex items-start gap-2 rounded-md bg-success/10 px-3 py-2 text-sm">
          <Check className="mt-0.5 size-4 shrink-0 text-success" />
          <span>
            <span className="font-medium text-success">It works.</span> A call reached
            Toolport after this check started: <code className="text-xs">{hit.tool}</code>
            {hit.server ? (
              <>
                {" "}
                on <code className="text-xs">{hit.server}</code>
              </>
            ) : null}
            . Local stdio calls are not tagged with a client, so this is not proof it came
            from {client.name}.
          </span>
        </div>
      ) : (
        <>
          {status === "waiting" && (
            <>
              <p className="text-xs text-muted-foreground">
                In {client.name}, ask your agent to run this. It's read-only, it just
                lists your tools through Toolport.
              </p>
              <div className="flex items-center gap-2 rounded border bg-background px-2 py-1.5">
                <code className="min-w-0 flex-1 truncate text-xs">{prompt}</code>
                <button
                  type="button"
                  onClick={() => void copyPrompt()}
                  aria-label="Copy the prompt"
                  className="shrink-0 rounded p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                >
                  <Copy className="size-3.5" />
                </button>
              </div>
            </>
          )}

          {status === "snapshot" || status === "waiting" ? (
            <div className="flex items-start gap-2 text-xs text-muted-foreground">
              <Loader2 className="mt-0.5 size-3.5 shrink-0 animate-spin" />
              <span>
                {status === "snapshot"
                  ? "Reading the audit log so older calls cannot count as proof."
                  : `Waiting for a new call after this check started. Just connected ${client.name}? ${clientRestartHint(client.name)}`}
              </span>
            </div>
          ) : status === "snapshot-failed" ? (
            <div className="flex flex-col gap-1.5 rounded-md bg-warning/10 px-3 py-2 text-xs">
              <span className="font-medium text-warning">
                Couldn&apos;t read the audit log, so this check did not start.
              </span>
              <span className="text-muted-foreground">
                An older or unrelated call will not be treated as proof. Retry when the
                log is available, or use the Playground.
              </span>
              <button
                type="button"
                onClick={() => setSnapshotAttempt((n) => n + 1)}
                className="self-start font-medium text-primary hover:underline"
              >
                Retry the check
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-1.5 rounded-md bg-warning/10 px-3 py-2 text-xs">
              <span className="font-medium text-warning">No call yet. Common fixes:</span>
              <ul className="ml-3 list-disc space-y-0.5 text-muted-foreground">
                <li>{clientRestartHint(client.name)}</li>
                <li>Make sure it's scoped to a profile that has servers (Settings).</li>
                <li>If a server needs sign-in, authenticate it first.</li>
                <li>Check that each server started on the main screen.</li>
              </ul>
            </div>
          )}

          <button
            type="button"
            onClick={onOpenPlayground}
            className="self-start text-xs font-medium text-primary hover:underline"
          >
            Or test a tool in the Playground instead
          </button>
        </>
      )}
    </div>
  );
}

/** "Claude", "Claude and Cursor", "Claude, Cursor, and VS Code". */
function listJoin(items: string[]): string {
  if (items.length <= 1) return items[0] ?? "";
  if (items.length === 2) return `${items[0]} and ${items[1]}`;
  return `${items.slice(0, -1).join(", ")}, and ${items[items.length - 1]}`;
}
