import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from "react";
import { listen } from "@tauri-apps/api/event";
import {
  Check,
  FileCode2,
  Globe,
  Loader2,
  Monitor,
  ShieldAlert,
  Trash2,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { decideApproval, listPendingApprovals, type ApprovalScope } from "@/lib/api";
import type { PendingApproval } from "@/lib/types";
import { openExternal } from "@/lib/openUrl";
import { toastError } from "@/lib/toast";

/** Fail-closed window (must match approval::DEFAULT_TIMEOUT_SECS on the gateway). A
 * pending call that isn't decided within this is auto-denied, so we show a countdown. */
const TIMEOUT_MS = 120_000;

type Reason = PendingApproval["reason"];

function routineApprovalView(value: unknown) {
  if (!value || typeof value !== "object") return null;
  const payload = value as Record<string, unknown>;
  const evidence =
    payload.evidence && typeof payload.evidence === "object"
      ? (payload.evidence as Record<string, unknown>)
      : undefined;
  const dependencies = evidence?.observedDependencies;
  return {
    name: typeof payload.name === "string" ? payload.name : "Unnamed routine",
    description: typeof payload.description === "string" ? payload.description : null,
    risk: typeof payload.riskClass === "string" ? payload.riskClass : "unknown",
    calls: evidence?.calls,
    dependencies: Array.isArray(dependencies) ? dependencies : [],
    synthesized: payload.provenance === "synthesized_from_observed_calls",
    technical: payload,
  };
}

/** How each gate reason presents: label, badge tone, and an icon. */
const REASON: Record<Reason, { label: string; className: string; Icon: typeof Trash2 }> =
  {
    destructive: {
      label: "Destructive",
      className: "bg-destructive/10 text-destructive",
      Icon: Trash2,
    },
    untrusted_source: {
      label: "Untrusted source",
      className: "bg-warning/15 text-warning",
      Icon: Globe,
    },
    destructive_and_untrusted: {
      label: "Destructive · untrusted",
      className: "bg-destructive/10 text-destructive",
      Icon: Trash2,
    },
    persistent_code_write: {
      label: "Persistent code",
      className: "bg-warning/15 text-warning",
      Icon: FileCode2,
    },
    pii_cross_server: {
      label: "Releases private data",
      className: "bg-destructive/10 text-destructive",
      Icon: ShieldAlert,
    },
  };

/**
 * The human-in-the-loop queue: tool calls and URL elicitations the gateway is holding
 * until you act. The call BLOCKS on your decision, so this is mounted globally
 * (actionable from any view) and renders nothing when the queue is empty. It polls as a
 * safety net and refreshes immediately on the gateway's `approval-pending` /
 * `approval-resolved` events.
 */
export function PendingApprovals() {
  const [pending, setPending] = useState<PendingApproval[]>([]);
  // Ids with a decision in flight: shown dimmed + disabled, removed authoritatively by the
  // resolved event / poll (NOT optimistically), so a poll landing before the backend
  // reflects the decision can't flicker the row back looking un-decided.
  const [resolving, setResolving] = useState<Set<string>>(new Set());
  // Fallback only: first-sighting time per id, used to drive the countdown if a pending
  // entry ever lacks the broker's authoritative deadlineMs (older backend / transient).
  const seenAt = useRef<Map<string, number>>(new Map());
  const [now, setNow] = useState(() => Date.now());
  const dialogRef = useRef<HTMLDivElement>(null);
  const prevCount = useRef(0);

  const refresh = useCallback(async () => {
    try {
      const list = await listPendingApprovals();
      setPending(list);
      // Prune resolving ids the backend has confirmed gone (authoritative removal).
      setResolving((s) => {
        const ids = new Set(list.map((p) => p.id));
        const next = new Set([...s].filter((id) => ids.has(id)));
        return next.size === s.size ? s : next;
      });
    } catch {
      // Broker not up yet / transient — keep the current list rather than flashing empty.
    }
  }, []);

  useEffect(() => {
    void refresh();
    const poll = setInterval(() => void refresh(), 2000);
    const unlisten = Promise.all([
      listen("approval-pending", () => void refresh()),
      listen("approval-resolved", () => void refresh()),
    ]);
    return () => {
      clearInterval(poll);
      void unlisten.then((fns) => fns.forEach((f) => f()));
    };
  }, [refresh]);

  // Tick once a second while anything is pending, to drive the countdown.
  useEffect(() => {
    if (pending.length === 0) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [pending.length]);

  // Record first-sighting for new ids; drop entries that are gone.
  useEffect(() => {
    const ids = new Set(pending.map((p) => p.id));
    const t = Date.now();
    for (const p of pending) if (!seenAt.current.has(p.id)) seenAt.current.set(p.id, t);
    for (const id of seenAt.current.keys()) if (!ids.has(id)) seenAt.current.delete(id);
  }, [pending]);

  const decide = async (id: string, approved: boolean, scope: ApprovalScope = "once") => {
    setResolving((s) => new Set(s).add(id));
    try {
      await decideApproval(id, approved, scope);
      // Intentionally NOT removed here — the approval-resolved event + poll remove it.
    } catch (e) {
      toastError(`Couldn't record your decision: ${e}`);
      setResolving((s) => {
        const n = new Set(s);
        n.delete(id);
        return n;
      });
      void refresh();
    }
  };

  // When the queue first appears, move focus into the dialog so keyboard / screen-reader
  // users are taken to the (fail-closed, time-boxed) decision instead of silently missing it.
  useEffect(() => {
    if (prevCount.current === 0 && pending.length > 0) dialogRef.current?.focus();
    prevCount.current = pending.length;
  }, [pending.length]);

  if (pending.length === 0) return null;

  // Escape denies the oldest still-pending item — a fail-safe keyboard shortcut (deny is
  // the safe direction; the agent just retries).
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Escape") {
      const first = pending.find((p) => !resolving.has(p.id));
      if (first) void decide(first.id, false);
    }
  };

  return (
    <div className="pointer-events-none fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4">
      {/* Soft scrim to draw the eye without blocking the rest of the app. */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-background/70 to-transparent" />
      <div
        ref={dialogRef}
        tabIndex={-1}
        onKeyDown={onKeyDown}
        role="alertdialog"
        aria-modal="false"
        aria-label="Tool calls awaiting your approval"
        className="animate-in fade-in slide-in-from-top-2 pointer-events-auto relative w-full max-w-lg overflow-hidden rounded-xl border border-warning/40 bg-popover/95 shadow-2xl ring-1 ring-warning/10 backdrop-blur outline-none focus-visible:ring-2 focus-visible:ring-warning"
      >
        {/* Announce count changes to screen readers without re-announcing on every countdown
         * tick (the visible timer lives elsewhere; this text only changes when the count does). */}
        <div aria-live="assertive" className="sr-only">
          {pending.length} request{pending.length > 1 ? "s" : ""} awaiting your action.
          Press Escape to cancel.
        </div>
        <header className="flex items-center gap-3 border-b border-border/60 px-4 py-3">
          <span className="flex size-8 shrink-0 items-center justify-center rounded-full bg-warning/15 text-warning">
            <ShieldAlert className="size-4" />
          </span>
          <div className="min-w-0">
            <div className="text-sm font-semibold leading-tight">Action required</div>
            <div className="text-xs text-muted-foreground">
              {pending.length} request{pending.length > 1 ? "s" : ""} held — no action
              cancels it
            </div>
          </div>
        </header>

        <ul className="max-h-[70vh] divide-y divide-border/60 overflow-auto">
          {pending.map((a) => {
            const reason = REASON[a.reason];
            const urlElicitation = a.urlElicitation;
            const piiRelease = a.piiRelease;
            // Count down to the broker's authoritative deadline; fall back to
            // first-sighting + timeout only if deadlineMs is somehow absent, so the
            // timer is never blank.
            const seen = seenAt.current.get(a.id) ?? now;
            const deadline = a.deadlineMs ?? seen + TIMEOUT_MS;
            const remaining = Math.max(0, Math.ceil((deadline - now) / 1000));
            // Scale the bar against the ACTUAL window (deadline - first sighting), not
            // the hardcoded TIMEOUT_MS, so it stays accurate even if the gateway's
            // timeout ever drifts from this constant.
            const totalMs = Math.max(1000, deadline - seen);
            const pct = Math.max(0, Math.min(100, ((deadline - now) / totalMs) * 100));
            const urgent = remaining <= 20;
            const isBusy = resolving.has(a.id);
            return (
              <li key={a.id} className="px-4 py-3.5">
                <div className="mb-2 flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 font-mono text-sm">
                      {urlElicitation ? (
                        <span className="truncate font-medium text-foreground">
                          {urlElicitation.origin}
                        </span>
                      ) : (
                        <>
                          <span className="truncate text-muted-foreground">
                            {a.server}
                          </span>
                          <span className="text-muted-foreground/50">/</span>
                          <span className="truncate font-medium text-foreground">
                            {a.tool}
                          </span>
                        </>
                      )}
                    </div>
                    {a.client && (
                      <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
                        <Monitor className="size-3" />
                        Requested by {a.client}
                      </div>
                    )}
                  </div>
                  {urlElicitation ? (
                    <Badge className="bg-warning/15 text-warning">
                      <Globe className="size-3" />
                      External link
                    </Badge>
                  ) : (
                    <Badge className={reason.className}>
                      <reason.Icon className="size-3" />
                      {reason.label}
                    </Badge>
                  )}
                </div>

                {/* The release decision itself. Shown above the arguments because the
                    question is "may these values go to this server?", not "is this call
                    shaped correctly?". These are the real values, un-pseudonymized: this
                    window is the only place they appear, and the model never sees them. */}
                {piiRelease && (
                  <div className="mb-3">
                    <div className="mb-1 text-[0.7rem] font-medium uppercase tracking-wide text-muted-foreground">
                      Would send to {piiRelease.server}
                    </div>
                    <ul className="divide-y divide-border/60 rounded-md border border-destructive/40 bg-destructive/5">
                      {piiRelease.values.map((v) => (
                        <li key={v.token} className="p-2.5 text-xs">
                          <div className="font-mono break-all text-foreground">
                            {v.value}
                          </div>
                          <div className="mt-0.5 text-muted-foreground">
                            {v.token} · from {v.origins.join(", ")}
                          </div>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-1.5 text-xs text-muted-foreground">
                      {piiRelease.server} has never seen{" "}
                      {piiRelease.values.length === 1 ? "this value" : "these values"}.
                      Approving releases {piiRelease.values.length === 1 ? "it" : "them"}{" "}
                      to that server for the rest of this session, and nothing else.
                    </p>
                  </div>
                )}

                <div className="mb-3">
                  <div className="mb-1 text-[0.7rem] font-medium uppercase tracking-wide text-muted-foreground">
                    {urlElicitation
                      ? "Why this is needed"
                      : a.reason === "persistent_code_write"
                        ? "Routine definition"
                        : "Arguments"}
                  </div>
                  {urlElicitation ? (
                    <div className="rounded-md border border-border/60 bg-muted/40 p-2.5 text-sm leading-relaxed">
                      {urlElicitation.message}
                    </div>
                  ) : a.reason === "persistent_code_write" ? (
                    (() => {
                      const routine = routineApprovalView(a.arguments);
                      // Fail visible: a payload the structured view cannot render
                      // must still be shown raw - never an empty card with a live
                      // Approve button on a persistent write.
                      if (!routine) {
                        return (
                          <pre className="max-h-36 overflow-auto rounded-md border border-border/60 bg-muted/40 p-2.5 font-mono text-xs leading-relaxed">
                            {JSON.stringify(a.arguments, null, 2)}
                          </pre>
                        );
                      }
                      return (
                        <div className="space-y-2 rounded-md border border-border/60 bg-muted/40 p-2.5 text-sm">
                          <div className="font-medium text-foreground">
                            {routine.name}
                          </div>
                          {routine.description && (
                            <div className="text-xs leading-relaxed text-muted-foreground">
                              {routine.description}
                            </div>
                          )}
                          {routine.synthesized && (
                            <div className="rounded border border-warning/40 bg-warning/10 px-2 py-1 text-xs leading-relaxed text-warning">
                              Synthesized by Toolport from observed direct calls: every
                              listed call really ran, but the surrounding script was
                              generated and statically validated, not yet executed.
                            </div>
                          )}
                          <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                            <span>Risk: {routine.risk}</span>
                            {routine.calls !== undefined && (
                              <span>Calls: {String(routine.calls)}</span>
                            )}
                            {routine.dependencies.length > 0 && (
                              <span>
                                Dependencies:{" "}
                                {routine.dependencies
                                  .map((dependency) =>
                                    dependency &&
                                    typeof dependency === "object" &&
                                    "name" in dependency
                                      ? String(
                                          (dependency as Record<string, unknown>).name,
                                        )
                                      : String(dependency),
                                  )
                                  .join(", ")}
                              </span>
                            )}
                          </div>
                          <details>
                            <summary className="cursor-pointer text-xs font-medium text-muted-foreground hover:text-foreground">
                              Technical details
                            </summary>
                            <pre className="mt-2 max-h-36 overflow-auto rounded border border-border/60 bg-background/60 p-2 font-mono text-[0.7rem] leading-relaxed">
                              {JSON.stringify(routine.technical, null, 2)}
                            </pre>
                          </details>
                        </div>
                      );
                    })()
                  ) : (
                    <pre className="max-h-36 overflow-auto rounded-md border border-border/60 bg-muted/40 p-2.5 font-mono text-xs leading-relaxed">
                      {JSON.stringify(a.arguments, null, 2)}
                    </pre>
                  )}
                </div>

                <div className="flex items-center justify-between gap-3">
                  <div
                    className={
                      "flex items-center gap-1.5 text-xs tabular-nums " +
                      (urgent ? "text-destructive" : "text-muted-foreground")
                    }
                  >
                    <span
                      aria-hidden
                      className="inline-block h-1 w-16 overflow-hidden rounded-full bg-border"
                    >
                      <span
                        className={
                          "block h-full rounded-full transition-[width] duration-1000 ease-linear " +
                          (urgent ? "bg-destructive" : "bg-warning")
                        }
                        style={{ width: `${pct}%` }}
                      />
                    </span>
                    {remaining}s left
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <Button
                      size="sm"
                      variant="destructive"
                      disabled={isBusy}
                      onClick={() => void decide(a.id, false)}
                    >
                      {isBusy ? <Loader2 className="animate-spin" /> : <X />}
                      {urlElicitation ? "Cancel" : "Deny"}
                    </Button>
                    {urlElicitation && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={isBusy}
                        onClick={() => void openExternal(urlElicitation.url)}
                      >
                        <Globe />
                        Open link
                      </Button>
                    )}
                    <Button
                      size="sm"
                      disabled={isBusy}
                      onClick={() => void decide(a.id, true)}
                      className="bg-[color-mix(in_oklch,var(--success),black_16%)] text-white shadow-sm hover:bg-[color-mix(in_oklch,var(--success),black_26%)]"
                    >
                      {isBusy ? <Loader2 className="animate-spin" /> : <Check />}
                      {urlElicitation ? "Continue" : "Approve"}
                    </Button>
                  </div>
                </div>

                {/* Skip the prompt for this tool next time - curbs approval fatigue.
                    Never offered for a persistent code write (saving a routine is
                    always a one-shot decision on an exact definition), nor for a PII
                    release: the allow key binds a tool definition, and the broker
                    deliberately refuses to auto-approve a release on one (SBS-696).
                    Offering it here would promise a bypass that never fires. */}
                {!urlElicitation &&
                  a.reason !== "persistent_code_write" &&
                  !piiRelease && (
                    <div className="mt-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-muted-foreground">
                      <span>Skip next time?</span>
                      <button
                        disabled={isBusy}
                        onClick={() => void decide(a.id, true, "session")}
                        className="font-medium text-foreground/80 underline-offset-2 hover:text-foreground hover:underline disabled:opacity-50"
                      >
                        Allow for this session
                      </button>
                      <span className="text-muted-foreground/40">·</span>
                      <button
                        disabled={isBusy}
                        onClick={() => void decide(a.id, true, "always")}
                        className="font-medium text-foreground/80 underline-offset-2 hover:text-foreground hover:underline disabled:opacity-50"
                      >
                        Always allow this tool
                      </button>
                    </div>
                  )}
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
